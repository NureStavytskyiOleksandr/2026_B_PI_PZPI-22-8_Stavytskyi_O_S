using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterManager : MonoBehaviour
{
    public static MonsterManager Instance;

    [SerializeField] private GameObject[] enemies;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
    }

    public void Save(ref MonstersData data)
    {
        data.monstersAvailability = new bool[enemies.Length];
        for (int i = 0; i < enemies.Length; i++)
        {
            data.monstersAvailability[i] = enemies[i].gameObject.activeSelf;
        }
        Debug.Log("MonstersData saved");
    }
    public void Load(MonstersData data)
    {
        for (int i = 0; i < enemies.Length; i++)
        {
            enemies[i].gameObject.SetActive(data.monstersAvailability[i]);
        }
        Debug.Log("MonstersData loaded");
    }
}
[System.Serializable]
public struct MonstersData
{
    public bool[] monstersAvailability;
}