using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputManager : MonoBehaviour
{
    public static InputManager Instance;


    public event EventHandler OnPlayerAttack;

    public event EventHandler OnPlayerInteract;

    //public event EventHandler OnUsingMagicSwordSkill;
    //public event EventHandler OnUsingSwordRainSkill;
    //public event EventHandler OnUsingSwordCageSkill;

    public event EventHandler OnFirstSkillPerformed;
    public event EventHandler OnSecondSkillPerformed;
    public event EventHandler OnThirdSkillPerformed;

    //public event EventHandler On

    private PlayerActions playerActions;

    private void Awake()
    {
        Instance = this;
        playerActions = new PlayerActions();
        playerActions.PlayerActionMap.Enable();

        playerActions.PlayerActionMap.Attack.performed += Attack_performed;

        playerActions.PlayerActionMap.Interact.performed += Interact_performed;

        playerActions.PlayerActionMap.FirstSkill.performed += FirstSkill_performed;
        playerActions.PlayerActionMap.SecondSkill.performed += SecondSkill_performed;
        playerActions.PlayerActionMap.ThirdSkill.performed += ThirdSkill_performed;
    }
    private void FirstSkill_performed(UnityEngine.InputSystem.InputAction.CallbackContext obj)
    {
        OnFirstSkillPerformed?.Invoke(this, EventArgs.Empty);
    }
    private void SecondSkill_performed(UnityEngine.InputSystem.InputAction.CallbackContext obj)
    {
        OnSecondSkillPerformed?.Invoke(this, EventArgs.Empty);
    }

    private void ThirdSkill_performed(UnityEngine.InputSystem.InputAction.CallbackContext obj)
    {
        OnThirdSkillPerformed?.Invoke(this, EventArgs.Empty);
    }

    private void Interact_performed(UnityEngine.InputSystem.InputAction.CallbackContext obj)
    {
        OnPlayerInteract?.Invoke(this, EventArgs.Empty);
    }

    private void Attack_performed(UnityEngine.InputSystem.InputAction.CallbackContext obj)
    {
        OnPlayerAttack?.Invoke(this, EventArgs.Empty);
    }

    public Vector2 GetMovementVector()
    {
        return playerActions.PlayerActionMap.Move.ReadValue<Vector2>().normalized;
    }










    public void UseFirstSkill()
    {
        OnFirstSkillPerformed?.Invoke(this, EventArgs.Empty);
    }

    public void UseSecondSkill()
    {
        OnSecondSkillPerformed?.Invoke(this, EventArgs.Empty);
    }
    public void UseThirdSkill()
    {
        OnThirdSkillPerformed?.Invoke(this, EventArgs.Empty);
    }
}