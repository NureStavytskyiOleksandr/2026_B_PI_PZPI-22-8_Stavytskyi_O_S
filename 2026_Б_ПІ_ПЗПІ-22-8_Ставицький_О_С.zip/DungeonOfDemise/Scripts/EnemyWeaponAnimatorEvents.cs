using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyWeaponAnimatorEvents : MonoBehaviour
{
    [SerializeField] private EnemyWeapon enemyWeapon;
    
    public void Attack()
    {
        enemyWeapon.Attack();
    }
}
