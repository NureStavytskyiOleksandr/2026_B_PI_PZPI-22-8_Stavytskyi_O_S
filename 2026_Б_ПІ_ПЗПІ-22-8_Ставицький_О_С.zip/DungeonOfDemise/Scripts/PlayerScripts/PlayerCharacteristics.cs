using JetBrains.Annotations;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static Characteristic;

public class PlayerCharacteristics : MonoBehaviour, IEffectable
{
    public static PlayerCharacteristics Instance;

    [Header("�haracteristics")]
    [SerializeField] private List<Characteristic> baseCharacteristics;

    [SerializeField] private List<Characteristic> changedCharacteristics;

    [SerializeField] private List<Effect> effects;


    [Header("Level")]
    [SerializeField] private float targetExperience;
    [SerializeField] private float currentExperience;
    [SerializeField] private int level;
    [SerializeField] private int characteristicPoints;
    [SerializeField] private int skillPoints;

    private int usedCharacteristicPoints;

    [Header("Other")]
    [SerializeField] private Player�haracteristicsConfigSO �haracteristicsConfigSO;
    [SerializeField] private Animator LvlUpAnimator;
    [SerializeField] private int money;




    public event EventHandler OnExperienceChanged;
    public event EventHandler OnHealthChanged;
    public event EventHandler OnManaChanged;
    public event EventHandler OnSkillPointChanged;
    public event EventHandler OnCharacteristicPointChanged;
    public event EventHandler OnCharacteristicsChanged;
    public event EventHandler OnMoneyChanged;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }

        SetStartCharacteristics();
    }
    private void Start()
    {
        InventorySystem.Instance.OnEquipmentChanged += InventorySystem_OnEquipmentChanged;
    }

    private void InventorySystem_OnEquipmentChanged(object sender, EventArgs e)
    {
        CalculateEffects();
    }

    private void Update()
    {
        CheckEffects();
    }
    private void SetStartCharacteristics()
    {
        if (�haracteristicsConfigSO == null)
            return;

        // move speed, attack speed
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.moveSpeed, �haracteristicsConfigSO.moveSpeed);
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.attackSpeed, �haracteristicsConfigSO.attackSpeed);

        // health, mana
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.maxHeath, �haracteristicsConfigSO.health);
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.maxMana, �haracteristicsConfigSO.mana);
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.health, GetBaseCharacteristicValue(Characteristic.CharacteristicType.maxHeath));
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.mana, GetBaseCharacteristicValue(Characteristic.CharacteristicType.maxMana));

        // resistance
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.armor, �haracteristicsConfigSO.armor);
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.effectResistance, �haracteristicsConfigSO.effectsResistance);
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.magicResistance, �haracteristicsConfigSO.magicResistance);

        // block damage, magic power
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.blockingDamage, �haracteristicsConfigSO.blockingDamage);
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.magicPower, �haracteristicsConfigSO.magicPower);

        // experience
        level = 0;
        usedCharacteristicPoints = 0;
        targetExperience = �haracteristicsConfigSO.startTargetExperience;
        currentExperience = 0f;

        ResetChangedCharacteristics();

        OnExperienceChanged?.Invoke(this, EventArgs.Empty);
        OnHealthChanged?.Invoke(this, EventArgs.Empty);
        OnManaChanged?.Invoke(this, EventArgs.Empty);
    }
    private void SetBaseCharacteristicValue(Characteristic.CharacteristicType characteristicType, float valueToSet)
    {
        foreach (Characteristic characteristic in baseCharacteristics)
        {
            if (characteristic.type == characteristicType)
            {
                characteristic.value = valueToSet;
                return;
            }
        }
        return;
    }
    #region Effects 
    private void CheckEffects()
    {
        float deltaTime = Time.deltaTime;

        foreach (Effect effect in effects)
        {
            effect.UpdateEffectTime(deltaTime);
        }

        int removedCount = effects.RemoveAll(e => e.IsFinished());

        if (removedCount > 0)
        {
            CalculateEffects();
        }
    }
    public void ApplyEffect(Effect effectToAdd)
    {
        Effect effect = new Effect(effectToAdd.characteristicType, effectToAdd.interactType, effectToAdd.value, effectToAdd.interactionTime, effectToAdd.effectImage);

        effects.Add(effect);
        EffectsUI.Instance.AddEffect(effect.effectImage, effect.interactionTime);

        CalculateEffects();
    }
    public void ApplyEffect(Effect[] effectsToAdd)
    {
        foreach (Effect effectToAdd in effectsToAdd)
        {
            if (effectToAdd.characteristicType == Characteristic.CharacteristicType.health ||
               effectToAdd.characteristicType == Characteristic.CharacteristicType.mana)
                ChangeBaseCharacteristicValue(effectToAdd.characteristicType, effectToAdd.value);
            else
                ApplyEffect(effectToAdd);
        }
    }
    public void ApplyHostileEffect(Effect effectToAdd)
    {
        float resistance = GetBaseCharacteristicValue(Characteristic.CharacteristicType.effectResistance) / 100f;

        float newValue = effectToAdd.value * (1 - resistance);
        float newTime = effectToAdd.interactionTime * (1 - resistance);

        Effect effect = new Effect(effectToAdd.characteristicType, effectToAdd.interactType, newValue, newTime, effectToAdd.effectImage);

        effects.Add(effect);
        EffectsUI.Instance.AddEffect(effect.effectImage, effect.interactionTime);

        CalculateEffects();
    }

    public void ApplyHostileEffect(Effect[] effectsToAdd)
    {
        foreach (Effect effectToAdd in effectsToAdd)
        {
            ApplyHostileEffect(effectToAdd);
        }
    }
    private void CalculateEffects()
    {
        float currentHealth = GetBaseCharacteristicValue(Characteristic.CharacteristicType.health);
        float currentMaxHealth = GetChangedCharacteristicValue(Characteristic.CharacteristicType.maxHeath);
        float healthPercent = currentMaxHealth > 0 ? currentHealth / currentMaxHealth : 1f;

        float currentMana = GetBaseCharacteristicValue(Characteristic.CharacteristicType.mana);
        float currentMaxMana = GetChangedCharacteristicValue(Characteristic.CharacteristicType.maxMana);
        float manaPercent = currentMaxMana > 0 ? currentMana / currentMaxMana : 1f;


        ResetChangedCharacteristics();

        List<InventoryItem> equipment = InventorySystem.Instance.GetEquipment();

        if(equipment.Count > 0 )
        {
            foreach( InventoryItem item in equipment )
            {
                if (item.effects != null)
                {
                    foreach (var effect in item.effects)
                    {
                        Characteristic characteristic = GetChangedCharacteristic(effect.characteristicType);

                        switch (effect.interactType)
                        {
                            case Effect.InteractType.addition:
                                characteristic.value += effect.value;
                                break;

                            case Effect.InteractType.multiplication:
                                characteristic.value *= effect.value;
                                break;
                        }
                    }
                }
            }
        }

        foreach (var effect in effects)
        {
            Characteristic characteristic = GetChangedCharacteristic(effect.characteristicType);

            switch (effect.interactType)
            {
                case Effect.InteractType.addition:
                    characteristic.value += effect.value;
                    break;

                case Effect.InteractType.multiplication:
                    characteristic.value *= effect.value;
                    break;
            }
        }

        float newMaxHealth = GetChangedCharacteristicValue(Characteristic.CharacteristicType.maxHeath);
        float newMaxMana = GetChangedCharacteristicValue(Characteristic.CharacteristicType.maxMana);

        SetBaseCharacteristicValue(Characteristic.CharacteristicType.health, newMaxHealth * healthPercent);
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.mana, newMaxMana * manaPercent);

        OnHealthChanged?.Invoke(this, EventArgs.Empty);
        OnManaChanged?.Invoke(this, EventArgs.Empty);
    }

    #endregion

    private void ResetChangedCharacteristics()
    {
        changedCharacteristics = new List<Characteristic>();
        foreach (var baseCharacteristic in baseCharacteristics)
        {
            changedCharacteristics.Add(new Characteristic
            {
                type = baseCharacteristic.type,
                value = baseCharacteristic.value
            });
        }
    }
    public void GetExperience(float experience)
    {
        currentExperience += experience;

        OnExperienceChanged?.Invoke(this, EventArgs.Empty);

        CheckExperience();
    }

    private void CheckExperience()
    {
        if (currentExperience >= targetExperience)
        {
            LevelUp();
        }
    }

    public void LevelUp()
    {
        currentExperience -= targetExperience;
        targetExperience = targetExperience + �haracteristicsConfigSO.targetExperienceIncrement;

        level++;
        skillPoints++;
        characteristicPoints++;

        GetBaseCharacteristic(CharacteristicType.health).value = GetBaseCharacteristic(CharacteristicType.maxHeath).value;
        GetBaseCharacteristic(CharacteristicType.mana).value = GetBaseCharacteristic(CharacteristicType.maxMana).value;

        LvlUpAnimator.SetTrigger("LvlUp");

        OnExperienceChanged?.Invoke(this, EventArgs.Empty);
        OnCharacteristicPointChanged?.Invoke(this, EventArgs.Empty);
        OnHealthChanged?.Invoke(this, EventArgs.Empty);
        OnManaChanged?.Invoke(this, EventArgs.Empty);

        CheckExperience();
    }
    #region Base Characteristics
    public void UpgradeBaseCharacteristic(Characteristic.CharacteristicType characteristicType)
    {
        if (characteristicPoints <= 0)
            return;

        characteristicPoints--;
        usedCharacteristicPoints++;
        OnCharacteristicPointChanged?.Invoke(this, EventArgs.Empty);

        IncreaseBaseCharacteristic(characteristicType);

        if (usedCharacteristicPoints % 5 == 0)
        {
            foreach (Characteristic characteristic in baseCharacteristics)
            {
                if (characteristic.type == characteristicType)
                    continue;

                IncreaseBaseCharacteristic(characteristic.type);
            }
        }
    }
    private void IncreaseBaseCharacteristic(Characteristic.CharacteristicType characteristicType)
    {
        GetBaseCharacteristic(characteristicType).value += �haracteristicsConfigSO.GetCharacteristicInctement(characteristicType);

        CalculateEffects();

        OnCharacteristicsChanged?.Invoke(this, EventArgs.Empty);
    }
    public float GetBaseCharacteristicValue(Characteristic.CharacteristicType characteristicType)
    {
        foreach (Characteristic characteristic in baseCharacteristics)
        {
            if (characteristic.type == characteristicType)
            {
                return characteristic.value;
            }
        }

        return 0;
    }
    public Characteristic GetBaseCharacteristic(Characteristic.CharacteristicType characteristicType)
    {
        foreach (Characteristic characteristic in baseCharacteristics)
        {
            if (characteristic.type == characteristicType)
            {
                return characteristic;
            }
        }

        return default;
    }
    public bool HasEnoughBaseCharacteristicValue(Characteristic.CharacteristicType characteristicType, float value)
    {
        Characteristic characteristic = GetBaseCharacteristic(characteristicType);

        return characteristic.value >= value;
    }
    public void ChangeBaseCharacteristicValue(Characteristic.CharacteristicType characteristicType, float value)
    {
        Characteristic characteristic = GetBaseCharacteristic(characteristicType);

        if (characteristic.type == Characteristic.CharacteristicType.mana)
        {
            characteristic.value += value;
            if (characteristic.value > GetBaseCharacteristicValue(Characteristic.CharacteristicType.maxMana))
            {
                characteristic.value = GetBaseCharacteristicValue(Characteristic.CharacteristicType.maxMana);
            }
            else if (characteristic.value < 0)
            {
                characteristic.value = 0;
            }
            OnManaChanged?.Invoke(this, EventArgs.Empty);
        }
        else if (characteristic.type == Characteristic.CharacteristicType.health)
        {
            characteristic.value += value;
            if (characteristic.value > GetBaseCharacteristicValue(Characteristic.CharacteristicType.maxHeath))
            {
                characteristic.value = GetBaseCharacteristicValue(Characteristic.CharacteristicType.maxHeath);
            }
            else if (characteristic.value < 0)
            {
                characteristic.value = 0;
            }
            OnHealthChanged?.Invoke(this, EventArgs.Empty);
        }
    }
    #endregion
    #region Changed Characteristics
    private Characteristic GetChangedCharacteristic(Characteristic.CharacteristicType characteristicType)
    {
        foreach (Characteristic characteristic in changedCharacteristics)
        {
            if (characteristic.type == characteristicType)
            {
                return characteristic;
            }
        }

        return default;
    }
    public float GetChangedCharacteristicValue(Characteristic.CharacteristicType characteristicType)
    {
        foreach (Characteristic characteristic in changedCharacteristics)
        {
            if (characteristic.type == characteristicType)
            {
                return characteristic.value;
            }
        }

        return 0;
    }
    #endregion
    #region Damage
    public void TakeDamage(Damage damage)
    {
        switch (damage.damageType)
        {
            case Damage.DamageType.Physical:
                float finalDamage = Math.Max(0, (damage.damageAmount - GetChangedCharacteristicValue(Characteristic.CharacteristicType.blockingDamage)) * (1 - (GetChangedCharacteristicValue(Characteristic.CharacteristicType.armor) / 100)));
                GetBaseCharacteristic(Characteristic.CharacteristicType.health).value -= (float)Math.Round(finalDamage, 1);
                GetBaseCharacteristic(Characteristic.CharacteristicType.health).value = (float)Math.Round(GetBaseCharacteristicValue(Characteristic.CharacteristicType.health), 1);
                break;
            case Damage.DamageType.Magical:
                GetBaseCharacteristic(Characteristic.CharacteristicType.health).value -= (float)Math.Round(damage.damageAmount * (1 - (GetChangedCharacteristicValue(Characteristic.CharacteristicType.magicResistance) / 100)), 1);
                GetBaseCharacteristic(Characteristic.CharacteristicType.health).value = (float)Math.Round(GetBaseCharacteristicValue(Characteristic.CharacteristicType.health), 1);
                break;
        }
        DeathHandler();
        OnHealthChanged?.Invoke(this, EventArgs.Empty);
    }
    private void DeathHandler()
    {
        if (GetBaseCharacteristicValue(Characteristic.CharacteristicType.health) <= 0)
        {
            Player.Instance.DeathHandler();
        }
    }
    #endregion
    public int GetLevel()
    {
        return level;
    }
    public int GetSkillPoints()
    {
        return skillPoints;
    }
    public float GetTargetExperience()
    {
        return targetExperience;
    }
    public float GetCurrentExperience()
    {
        return currentExperience;
    }
    public int GetCharacteristicPoints()
    {
        return characteristicPoints;
    }
    public void SubtractSkillPoints()
    {
        skillPoints--;
        OnSkillPointChanged?.Invoke(this, EventArgs.Empty);
    }

    public void Save(ref PlayerCharacteristicsData data)
    {
        data.position = transform.position;
        data.health = GetBaseCharacteristicValue(Characteristic.CharacteristicType.health);
        data.mana = GetBaseCharacteristicValue(Characteristic.CharacteristicType.mana);

        data.baseCharacteristics = baseCharacteristics;
        data.changedCharacteristics = changedCharacteristics;

        data.targetExperience = targetExperience;
        data.currentExperience = currentExperience;
        data.level = level;
        data.skillPoints = skillPoints;
        data.usedCharacteristicPoints = usedCharacteristicPoints;
        data.characteristicPoints = characteristicPoints;
        data.money = money;
        Debug.Log("player saved");
    }
    public void Load(PlayerCharacteristicsData data)
    {
        transform.position = data.position;
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.health, data.health);
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.mana, data.mana);

        baseCharacteristics = data.baseCharacteristics;
        changedCharacteristics = data.changedCharacteristics;

        targetExperience = data.targetExperience;
        currentExperience = data.currentExperience;
        level = data.level;
        skillPoints = data.skillPoints;
        usedCharacteristicPoints = data.usedCharacteristicPoints;
        characteristicPoints = data.characteristicPoints;
        money = data.money;

        //SettingsAfterLoad();
        CalculateEffects();
        Debug.Log("player loaded");
    }

    private void SettingsAfterLoad()
    {
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.maxHeath, �haracteristicsConfigSO.health);
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.effectResistance, �haracteristicsConfigSO.effectsResistance);
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.blockingDamage, �haracteristicsConfigSO.blockingDamage);

        SetBaseCharacteristicValue(Characteristic.CharacteristicType.attackSpeed, �haracteristicsConfigSO.attackSpeed);
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.armor, �haracteristicsConfigSO.armor);

        SetBaseCharacteristicValue(Characteristic.CharacteristicType.maxMana, �haracteristicsConfigSO.mana);
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.magicResistance, �haracteristicsConfigSO.magicResistance);
        SetBaseCharacteristicValue(Characteristic.CharacteristicType.magicPower, �haracteristicsConfigSO.magicPower);

        ResetChangedCharacteristics();

        OnExperienceChanged?.Invoke(this, EventArgs.Empty);
        OnHealthChanged?.Invoke(this, EventArgs.Empty);
        OnManaChanged?.Invoke(this, EventArgs.Empty);
    }
    public void AddMoney(int amount)
    {
        money += amount;
        OnMoneyChanged?.Invoke(this, EventArgs.Empty);
    }
    public void SubtractMoney(int amount)
    {
        money -= amount;
        if(money < 0)
            money = 0;
        OnMoneyChanged?.Invoke(this, EventArgs.Empty);
    }
    public bool HasEnoughMoney(int amount)
    {
        return amount <= money;
    }
    public int GetMoney()
    {
        return money;
    }
}

[System.Serializable]
public struct PlayerCharacteristicsData
{
    public Vector3 position;

    public List<Characteristic> baseCharacteristics;
    public List<Characteristic> changedCharacteristics;

    public float health;
    public float mana;
    public float targetExperience;
    public float currentExperience;
    public int level;
    public int skillPoints;
    public int usedCharacteristicPoints;
    public int characteristicPoints;
    public int money;
}