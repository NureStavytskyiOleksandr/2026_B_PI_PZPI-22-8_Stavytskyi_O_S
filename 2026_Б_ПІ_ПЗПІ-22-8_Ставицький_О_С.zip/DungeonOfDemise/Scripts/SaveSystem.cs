using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
public class SaveSystem
{
    private static SaveData saveData = new SaveData();

    [System.Serializable]
    public struct SaveData
    {
        public InventorySystemData inventoryData;
        public SkillsData skillsData;
        public PlayerCharacteristicsData playerCharacteristicsData;
        public MechanismsData mechanismsData;
        public BarrelsData barrelsData;
        public MonstersData monstersData;
    }

    public static string SaveFileName()
    {
        string saveFile = Application.persistentDataPath + "/save" + ".save";
        return saveFile;
    }

    public static void Save()
    {
        HandleSaveData();

        //File.WriteAllText(SaveFileName(), JsonUtility.ToJson(saveData, true));

        string json = JsonUtility.ToJson(saveData, true);
        string encryptedData = EncryptionUtility.EncryptString(json);

        File.WriteAllText(SaveFileName(), encryptedData);
    }
    private static void HandleSaveData()
    {
        InventorySystem.Instance.Save(ref saveData.inventoryData);
        SkillManager.Instance.Save(ref saveData.skillsData);
        PlayerCharacteristics.Instance.Save(ref saveData.playerCharacteristicsData);
        MechanicalManager.Instance.Save(ref saveData.mechanismsData);
        BarrelsManager.Instance.Save(ref saveData.barrelsData);
        MonsterManager.Instance.Save(ref saveData.monstersData);
    }
    public static void Load()
    {
        string path = SaveFileName();

        if (!SaveExists())
        {
            return;
        }

        string saveContent = File.ReadAllText(path);
        string decryptedData = EncryptionUtility.DecryptString(saveContent);

        saveData = JsonUtility.FromJson<SaveData>(decryptedData);


        //saveData = JsonUtility.FromJson<SaveData>(saveContent);


        HandleLoadData();
    }

    private static void HandleLoadData()
    {
        InventorySystem.Instance.Load(saveData.inventoryData);
        SkillManager.Instance.Load(saveData.skillsData);
        PlayerCharacteristics.Instance.Load(saveData.playerCharacteristicsData);
        MechanicalManager.Instance.Load(saveData.mechanismsData);
        BarrelsManager.Instance.Load(saveData.barrelsData);
        MonsterManager.Instance.Load(saveData.monstersData);
    }

    public static bool SaveExists()
    {
        return File.Exists(SaveFileName());
    }
}
