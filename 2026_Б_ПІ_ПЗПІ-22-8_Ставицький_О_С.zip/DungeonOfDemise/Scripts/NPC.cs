using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPC : MonoBehaviour, IInteractable
{
    [SerializeField] private DialogueSO dialogueSO;
    [SerializeField] private PriceListSO priceListSO;

    [SerializeField] private bool openShop;
    public void Interact()
    {
        if(openShop)
            ShopSystem.Instance.StartShop(priceListSO);
        else
            DialogueManager.Instance.StartDialogue(dialogueSO);
    }
}
