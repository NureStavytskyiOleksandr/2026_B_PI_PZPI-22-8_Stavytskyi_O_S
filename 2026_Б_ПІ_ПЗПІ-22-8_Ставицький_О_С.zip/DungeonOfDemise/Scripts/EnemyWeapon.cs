using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyWeapon : MonoBehaviour
{
    [Header("WeaponSettings")]
    [SerializeField] private WeaponType weaponType;
    [SerializeField] private Damage damage;
    [SerializeField] private LayerMask attackLayer;


    [Header("Melle")]
    [SerializeField] private Transform attackPoint;
    [SerializeField] private float attackPointRange;


    [Header("Range")]
    [SerializeField] private Transform projectTileSpawnPoint;
    [SerializeField] private Arrow projectTile;
    [SerializeField] private Transform targetPos;


    [Header("Other")]
    [SerializeField] private Animator animator;


    private const string ATTACK_TRIGGER = "Attack";

    public enum WeaponType
    {
        Melle,
        Range
    }
    public void StartAttackAnimation(Damage damage, Transform target)
    {
        this.damage = damage;
        targetPos = target;
        animator.SetTrigger(ATTACK_TRIGGER);
    }
    public void Attack()
    {
        switch (weaponType)
        {
            case WeaponType.Melle:
                MelleAttack();
                break;
            case WeaponType.Range:
                RangeAttack();
                break;
        }
    }
    private void MelleAttack()
    {
        Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(attackPoint.position, attackPointRange, attackLayer);

        foreach (Collider2D enemy in hitEnemies)
        {
            if (enemy.TryGetComponent<IDamageable>(out var damageable))
            {
                damageable.TakeDamage(damage);
            }
        }
    }
    public void RangeAttack()
    {
        Arrow arrow = Instantiate(projectTile, projectTileSpawnPoint.position, Quaternion.identity);
        if(targetPos != null)
            arrow.Initialize(targetPos.position, damage);
    }
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        if (weaponType == WeaponType.Melle)
        {
            if (attackPoint == null) 
                return;

            Gizmos.DrawWireSphere(attackPoint.position, attackPointRange);
        }
        else
        {
            if (projectTileSpawnPoint == null) 
                return;

            Gizmos.DrawWireSphere(projectTileSpawnPoint.position, 0.1f);
        }
    }
}
