using System;
using System.Collections;
using UnityEngine;

public class SkillManager : MonoBehaviour
{
    public static SkillManager Instance;

    public SkillHandler[] skills;

    [SerializeField] public int FirstSkillID { get; private set; } = -1;
    [SerializeField] public int SecondSkillID { get; private set; } = -1;
    [SerializeField] public int ThirdSkillID { get; private set; } = -1;


    public event EventHandler OnFirstSkillUsed;
    public event EventHandler OnSecondSkillUsed;
    public event EventHandler OnThirdSkillUsed;


    [SerializeField] private Transform skillSpawnPosition;


    private void Awake()
    {
        if(Instance == null)
        {
            Instance = this;
        }
    }

    void Start()
    {
        InputManager.Instance.OnFirstSkillPerformed += InputManager_OnFirstSkillPerformed;
        InputManager.Instance.OnSecondSkillPerformed += InputManager_OnSecondSkillPerformed;
        InputManager.Instance.OnThirdSkillPerformed += InputManager_OnThirdSkillPerformed;
    }


    public void SetSkill(int skillID, int skillSlot)
    {
        if (FirstSkillID == skillID)
            FirstSkillID = -1;

        if (SecondSkillID == skillID)
            SecondSkillID = -1;

        if (ThirdSkillID == skillID)
            ThirdSkillID = -1;

        switch (skillSlot)
        {
            case 1:
                FirstSkillID = skillID;
                break;
            case 2: 
                SecondSkillID = skillID;
                break;
            case 3:
                ThirdSkillID = skillID;
                break;
        }
    }

    public SkillHandler GetSkillHandlerData(int skillID)
    {
        foreach (SkillHandler skill in skills)
        {
            if(skill.skillID == skillID)
            {
                return skill;
            }
        }
        return null;
    }
    public float GetSkillCooldown(int skillID)
    {
        SkillHandler skill = GetSkillHandlerData(skillID);

        return skill.skillLevel > 0 ? skill.skillSO.generalLevels[skill.skillLevel - 1].cooldown : 0;
    }

    public bool DoesSkillAcquired(int skillID)
    {
        SkillHandler skill = GetSkillHandlerData(skillID);

        return skill.skillLevel > 0;
    }
    private bool InitializeSkill(int skillID)
    {
        SkillHandler skill = GetSkillHandlerData(skillID);

        if (skill.skillLevel < 1)
            return false;

        if (skill.isInCooldown)
            return false;

        //if (PlayerStats.Instance.HasEnoughMana(skill.skillSO.generalLevels[skill.skillLevel - 1].manaCost))
        if (PlayerCharacteristics.Instance.HasEnoughBaseCharacteristicValue(Characteristic.CharacteristicType.mana, skill.skillSO.generalLevels[skill.skillLevel - 1].manaCost))
        {
            //PlayerStats.Instance.SubtractMana(skill.skillSO.generalLevels[skill.skillLevel - 1].manaCost);
            PlayerCharacteristics.Instance.ChangeBaseCharacteristicValue(Characteristic.CharacteristicType.mana, -(skill.skillSO.generalLevels[skill.skillLevel - 1].manaCost));

            skill.skillSO.Activate(skillSpawnPosition, skill.skillLevel);

            StartCoroutine(StartSkillCooldownRoutine(skill));

            return true;
        }

        return false;
    }

    IEnumerator StartSkillCooldownRoutine(SkillHandler skill)
    {
        skill.isInCooldown = true;

        yield return new WaitForSeconds(skill.skillSO.generalLevels[skill.skillLevel - 1].cooldown);

        skill.isInCooldown = false;
    }


    private void InputManager_OnFirstSkillPerformed(object sender, EventArgs e)
    {
        if (InitializeSkill(FirstSkillID))
        {
            OnFirstSkillUsed?.Invoke(this, EventArgs.Empty);
        }
    }
    private void InputManager_OnSecondSkillPerformed(object sender, EventArgs e)
    {
        if (InitializeSkill(SecondSkillID))
        {
            OnSecondSkillUsed?.Invoke(this, EventArgs.Empty);
        }
    }

    private void InputManager_OnThirdSkillPerformed(object sender, EventArgs e)
    {
        if (InitializeSkill(ThirdSkillID))
        {
            OnThirdSkillUsed?.Invoke(this, EventArgs.Empty);
        }
    }

    public void UpgradeSkill(int skillID)
    {
        SkillHandler skillHandler = GetSkillHandlerData(skillID);

        skillHandler.skillLevel++;
    }

    public void Save(ref SkillsData data)
    {
        data.skills = skills;
        data.firstSkillID = FirstSkillID;
        data.secondSkillID = SecondSkillID;
        data.thirdSkillID = ThirdSkillID;

        Debug.Log("SkillsData saved");
    }
    public void Load(SkillsData data)
    {
        skills = data.skills;
        FirstSkillID = data.firstSkillID;
        SecondSkillID = data.secondSkillID;
        ThirdSkillID = data.thirdSkillID;

        InputUI.Instance.Show();

        Debug.Log("SkillsData loaded");
    }
}

[System.Serializable]
public struct SkillsData
{
    public SkillHandler[] skills;
    public int firstSkillID;
    public int secondSkillID;
    public int thirdSkillID;
}
