using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PotionSlotUI : MonoBehaviour
{
    [SerializeField] private Button potionSlotButton;
    [SerializeField] private TextMeshProUGUI potionSlotAmountText;
    [SerializeField] private Image potionImage;
    [SerializeField] private int slotIndex;


    private void Start()
    {
        potionSlotButton.onClick.AddListener(() =>
        {
            InventorySystem.Instance.UseItemInSlot(slotIndex);
        });

        InventorySystem.Instance.OnInventoryChanged += PlayerInventory_OnInventoryChanged;
        UpdateImage();
    }

    private void PlayerInventory_OnInventoryChanged(object sender, System.EventArgs e)
    {
        UpdateImage();
    }

    public void UpdateImage()
    {
        if (InventorySystem.Instance.IsSlotOccupied(slotIndex))
        {
            InventorySlot item = InventorySystem.Instance.GetSlotData(slotIndex);
            SetImage(item.item.spriteUI);
            SetText(item.amount);
        }
        else
        {
            DeleteImage();
            potionSlotAmountText.text = "";
        }
    }
    private void SetText(int amount)
    {
        potionSlotAmountText.text = amount > 1 ? amount.ToString() : "";
    }
    private void SetImage(Sprite sprite)
    {
        potionImage.sprite = sprite;
        potionImage.color = Color.white;
        potionImage.SetNativeSize();
    }
    private void DeleteImage()
    {
        potionImage.sprite = null;
        potionImage.color = Color.clear;
    }
}
