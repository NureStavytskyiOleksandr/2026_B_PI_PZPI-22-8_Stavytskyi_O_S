using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class InventorySlotUI : MonoBehaviour
{
    [SerializeField] private InventoryUI inventoryUI;

    [SerializeField] private Button slotButton;
    [SerializeField] private TextMeshProUGUI slotAmountText;
    [SerializeField] private Image image;
    [SerializeField] private int slotIndex;
    [SerializeField] private InventoryItem.ItemType slotType;
    [SerializeField] private Sprite slotTypeSprite;


    private void Start()
    {
        slotButton.onClick.AddListener(() =>
        {
            inventoryUI.SelectSlot(slotIndex, slotType, transform.position);
        });

        InventorySystem.Instance.OnInventoryChanged += PlayerInventory_OnInventoryChanged;
    }

    private void PlayerInventory_OnInventoryChanged(object sender, System.EventArgs e)
    {
        UpdateImage();
    }
    
    public void UpdateImage()
    {
        if (InventorySystem.Instance.IsSlotOccupied(slotIndex))
        {
            InventorySlot item = InventorySystem.Instance.GetSlotData(slotIndex);
            SetImage(item.item.spriteUI);
            SetText(item.amount);
        }
        else
        {
            DeleteImage();
            slotAmountText.text = "";
        }
    }
    private void SetText(int amount)
    {
        slotAmountText.text = amount > 1 ? amount.ToString() : "";
    }
    private void SetImage(Sprite sprite)
    {
        image.sprite = sprite;
        image.color = Color.white;
        image.SetNativeSize();
    }
    private void DeleteImage()
    {
        image.sprite = null;
        image.color = Color.clear;
        if (slotTypeSprite != null)
            SetImage(slotTypeSprite);
    }
}
