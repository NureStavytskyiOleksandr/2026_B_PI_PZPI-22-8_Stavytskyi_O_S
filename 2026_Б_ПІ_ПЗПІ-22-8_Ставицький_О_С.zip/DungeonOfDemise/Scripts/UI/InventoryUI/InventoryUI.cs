using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using static Characteristic;

public class InventoryUI : MonoBehaviour
{
    [SerializeField] private Image selectedSlotImage;
    [SerializeField] private InventorySlotUI[] inventorySlotsUI;
    [SerializeField] private TextMeshProUGUI equipmentEffectsText;
    private int selectedSlotIndex = -1;


    private void Start()
    {
        InventorySystem.Instance.OnEquipmentChanged += InventorySystem_OnEquipmentChanged;
    }
    private string GetCharacteristicName(CharacteristicType type)
    {
        switch (type)
        {
            case CharacteristicType.maxHeath:
                return "����. ������'�";
            case CharacteristicType.health:
                return "������'�";
            case CharacteristicType.maxMana:
                return "����. ����";
            case CharacteristicType.mana:
                return "����";
            case CharacteristicType.attackSpeed:
                return "�������� �����";
            case CharacteristicType.magicPower:
                return "������ ����";
            case CharacteristicType.blockingDamage:
                return "���������� �����";
            case CharacteristicType.armor:
                return "�����";
            case CharacteristicType.magicResistance:
                return "��� ��㳿";
            case CharacteristicType.effectResistance:
                return "��� �������";
            case CharacteristicType.moveSpeed:
                return "�������� ����";
            default:
                return type.ToString();
        }
    }
    private void InventorySystem_OnEquipmentChanged(object sender, System.EventArgs e)
    {
        List<InventoryItem> equipment = InventorySystem.Instance.GetEquipment();

        equipmentEffectsText.text = "";

        Dictionary<CharacteristicType, float> summedEffects =
        new Dictionary<CharacteristicType, float>();

        if (equipment.Count > 0)
        {
            foreach (InventoryItem item in equipment)
            {
                if (item.effects != null)
                {
                    foreach (var effect in item.effects)
                    {
                        if (summedEffects.ContainsKey(effect.characteristicType))
                        {
                            summedEffects[effect.characteristicType] += effect.value;
                        }
                        else
                        {
                            summedEffects.Add(effect.characteristicType, effect.value);
                        }
                    }
                }
            }
        }
        foreach (var effect in summedEffects)
        {
            equipmentEffectsText.text += $"{GetCharacteristicName(effect.Key)} +{effect.Value}\n";
        }
    }

    public void UpdateInventoryImages()
    {
        foreach(InventorySlotUI slot in inventorySlotsUI)
        {
            slot.UpdateImage();
        }
    }

    public void SelectSlot(int slotIndex, InventoryItem.ItemType slotType, Vector3 posToSelect)
    {
        bool isSlotOccupied = InventorySystem.Instance.IsSlotOccupied(slotIndex);

        if(slotIndex == selectedSlotIndex)
        {
            selectedSlotIndex = -1;
            selectedSlotImage.gameObject.SetActive(false);
        }
        else if(AnySlotSelected() && isSlotOccupied)
        {
            if(InventorySystem.Instance.GetItemData(selectedSlotIndex).itemType == slotType ||
               slotType == InventoryItem.ItemType.Material)
            {
                selectedSlotImage.gameObject.SetActive(false);
                InventorySystem.Instance.SwitchTwoSlots(selectedSlotIndex, slotIndex);
                selectedSlotIndex = -1;
            }
        }
        else if (!AnySlotSelected() && isSlotOccupied)
        {
            selectedSlotImage.gameObject.transform.position = posToSelect;
            selectedSlotImage.gameObject.SetActive(true);
            selectedSlotIndex = slotIndex;
        }
        else if(AnySlotSelected() && !isSlotOccupied)
        {
            if (InventorySystem.Instance.GetItemData(selectedSlotIndex).itemType == slotType ||
               slotType == InventoryItem.ItemType.Material)
            {
                selectedSlotImage.gameObject.SetActive(false);
                InventorySystem.Instance.SwitchSlot(selectedSlotIndex, slotIndex);
                selectedSlotIndex = -1;
            }
        }
        else
        {
            selectedSlotImage.gameObject.SetActive(false);
        }
    }

    private bool AnySlotSelected()
    {
        return selectedSlotIndex >= 0;
    }
    public void Show()
    {
        gameObject.SetActive(true);
    }
    public void Hide()
    {
        gameObject.SetActive(false);
    }
}
