using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;


public class DialogueUI : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI textComponent;
    [SerializeField] private float textSpeed;
    [SerializeField] private TextMeshProUGUI talkerName;
    [SerializeField] private Image talkerFace;
    [SerializeField] private Transform dialogueOptions;

    [SerializeField] private DialogueOptionSingleUI dialogueOptionTemplate;


    private DialogueLine dialogueLine;
    private string sentance;

    public void Show()
    {
        gameObject.SetActive(true);
    }
    public void Hide()
    {
        gameObject.SetActive(false);
    }

    public void TypeDialogueLine(Sprite talkerFace, string talkerName, DialogueLine dialogueLine)
    {
        textComponent.text = string.Empty;
        sentance = dialogueLine.textLine;
        this.dialogueLine = dialogueLine;
        this.talkerFace.sprite = talkerFace;
        this.talkerName.text = talkerName;
        StartCoroutine(TypeLine());
        TypeOptions();
    }

    private void TypeOptions()
    {
        foreach (Transform child in dialogueOptions)
        {
            Destroy(child.gameObject);
        }
        if (dialogueLine.hasOptions)
        {
            foreach (DialogueOption dialogueOption in dialogueLine.options)
            {
                DialogueOptionSingleUI optionsSingle = Instantiate(dialogueOptionTemplate, dialogueOptions);
                optionsSingle.SetText(dialogueOption);
            }
        }
    }

    public void TypeSentance(string sentanceToType, Sprite talkerFace, string talkerName)
    {
        sentance = sentanceToType;
        textComponent.text = string.Empty;
        this.talkerFace.sprite = talkerFace;
        this.talkerName.text = talkerName;
        StartCoroutine(TypeLine());
    }

    private IEnumerator TypeLine()
    {
        foreach (char c in sentance.ToCharArray())
        {
            textComponent.text += c;
            yield return new WaitForSeconds(textSpeed);
        }
    }

    public void ShowFullText()
    {
        StopAllCoroutines();
        textComponent.text = sentance;
    }

    public bool IsLineTyped()
    {
        return textComponent.text == sentance;
    }
}