using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.U2D;
using UnityEngine.UI;

public class InputUI : MonoBehaviour
{
    public static InputUI Instance;

    [Header("First Skill")]
    [SerializeField] private GameObject firstSkillGameObject;
    [SerializeField] private Button firstSkillButton;
    [SerializeField] private Image firstSkillImage;
    [SerializeField] private Image firstSkillCooldownImage;
    private bool isFirstSkillInCooldown = false;

    [Header("Second Skill")]
    [SerializeField] private GameObject secondSkillGameObject;
    [SerializeField] private Button secondSkillButton;
    [SerializeField] private Image secondSkillImage;
    [SerializeField] private Image secondSkillCooldownImage;
    private bool isSecondSkillInCooldown = false;

    [Header("Third Skill")]
    [SerializeField] private GameObject thirdSkillGameObject;
    [SerializeField] private Button thirdSkillButton;
    [SerializeField] private Image thirdSkillImage;
    [SerializeField] private Image thirdSkillCooldownImage;
    private bool isThirdSkillInCooldown = false;



    private void Awake()
    {
        if(Instance == null)
        {
            Instance = this;
        }
    }
    void Start()
    {
        SkillManager.Instance.OnFirstSkillUsed += SkillManager_OnFirstSkillUsed;
        SkillManager.Instance.OnSecondSkillUsed += SkillManager_OnSecondSkillUsed;
        SkillManager.Instance.OnThirdSkillUsed += SkillManager_OnThirdSkillUsed;


        firstSkillButton.onClick.AddListener(() =>
        {
            if (!isFirstSkillInCooldown)
            {
                InputManager.Instance.UseFirstSkill();
            }
        });
        secondSkillButton.onClick.AddListener(() =>
        {
            if (!isSecondSkillInCooldown)
            {
                InputManager.Instance.UseSecondSkill();
            }
        });
        thirdSkillButton.onClick.AddListener(() =>
        {
            if (!isThirdSkillInCooldown)
            {
                InputManager.Instance.UseThirdSkill();
            }
        });

        Show();
    }

    private void SkillManager_OnFirstSkillUsed(object sender, System.EventArgs e)
    {
        if (!isFirstSkillInCooldown)
            StartCoroutine(FirstSkillCooldownRoutine(SkillManager.Instance.GetSkillCooldown(SkillManager.Instance.FirstSkillID)));
    }

    private void SkillManager_OnSecondSkillUsed(object sender, System.EventArgs e)
    {
        if (!isSecondSkillInCooldown)
            StartCoroutine(SecondSkillCooldownRoutine(SkillManager.Instance.GetSkillCooldown(SkillManager.Instance.SecondSkillID)));
    }

    private void SkillManager_OnThirdSkillUsed(object sender, System.EventArgs e)
    {
        if (!isThirdSkillInCooldown)
            StartCoroutine(ThirdSkillCooldownRoutine(SkillManager.Instance.GetSkillCooldown(SkillManager.Instance.ThirdSkillID)));
    }

    IEnumerator FirstSkillCooldownRoutine(float cooldownTime)
    {
        isFirstSkillInCooldown = true;
        float elapsed = 0f;
        firstSkillCooldownImage.fillAmount = 1f;

        while (elapsed < cooldownTime)
        {
            elapsed += Time.deltaTime;
            firstSkillCooldownImage.fillAmount = 1f - (elapsed / cooldownTime);
            yield return null;
        }

        firstSkillCooldownImage.fillAmount = 0f;
        isFirstSkillInCooldown = false;
    }
    IEnumerator SecondSkillCooldownRoutine(float cooldownTime)
    {
        isSecondSkillInCooldown = true;
        float elapsed = 0f;
        secondSkillCooldownImage.fillAmount = 1f;

        while (elapsed < cooldownTime)
        {
            elapsed += Time.deltaTime;
            secondSkillCooldownImage.fillAmount = 1f - (elapsed / cooldownTime);
            yield return null;
        }

        secondSkillCooldownImage.fillAmount = 0f;
        isSecondSkillInCooldown = false;
    }
    IEnumerator ThirdSkillCooldownRoutine(float cooldownTime)
    {
        isThirdSkillInCooldown = true;
        float elapsed = 0f;
        thirdSkillCooldownImage.fillAmount = 1f;

        while (elapsed < cooldownTime)
        {
            elapsed += Time.deltaTime;
            thirdSkillCooldownImage.fillAmount = 1f - (elapsed / cooldownTime);
            yield return null;
        }

        thirdSkillCooldownImage.fillAmount = 0f;
        isThirdSkillInCooldown = false;
    }
    public void Show()
    {
        UpdateSkillIcons();

        gameObject.SetActive(true);
    }

    public void UpdateSkillIcons()
    {
        if (SkillManager.Instance.FirstSkillID >= 0)
        {
            firstSkillGameObject.SetActive(SkillManager.Instance.DoesSkillAcquired(SkillManager.Instance.FirstSkillID));
            if (firstSkillGameObject.activeSelf)
            {
                Sprite sprite = SkillManager.Instance.GetSkillHandlerData(SkillManager.Instance.FirstSkillID).skillSO.skillImage;
                firstSkillImage.sprite = sprite;
                firstSkillCooldownImage.sprite = sprite;
            }
        }
        else
        {
            firstSkillGameObject.SetActive(false);
        }

        if (SkillManager.Instance.SecondSkillID >= 0)
        {
            secondSkillGameObject.SetActive(SkillManager.Instance.DoesSkillAcquired(SkillManager.Instance.SecondSkillID));
            if (secondSkillGameObject.activeSelf)
            {
                Sprite sprite = SkillManager.Instance.GetSkillHandlerData(SkillManager.Instance.SecondSkillID).skillSO.skillImage;
                secondSkillImage.sprite = sprite;
                secondSkillCooldownImage.sprite = sprite;
            }
        }
        else
        {
            secondSkillGameObject.SetActive(false);
        }

        if (SkillManager.Instance.ThirdSkillID >= 0)
        {
            thirdSkillGameObject.SetActive(SkillManager.Instance.DoesSkillAcquired(SkillManager.Instance.ThirdSkillID));
            if (thirdSkillGameObject.activeSelf)
            {
                Sprite sprite = SkillManager.Instance.GetSkillHandlerData(SkillManager.Instance.ThirdSkillID).skillSO.skillImage;
                thirdSkillImage.sprite = sprite;
                thirdSkillCooldownImage.sprite = sprite;
            }
        }
        else
        {
            thirdSkillGameObject.SetActive(false);
        }

    }
    public void Hide()
    {
        //gameObject.SetActive(false);
        if(gameObject.activeSelf)
            StartCoroutine(DelayedHide());
    }

    private IEnumerator DelayedHide()
    {
        yield return null;
        gameObject.SetActive(false);
    }
}
