using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EffectsUI : MonoBehaviour
{
    public static EffectsUI Instance;

    [SerializeField] private SingeEffectUI singeEffectUI;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
    }
    public void AddEffect(Sprite effectImage, float effectTime)
    {
        SingeEffectUI effect = Instantiate(singeEffectUI, this.gameObject.transform);
        effect.Initialize(effectImage, effectTime);
    }
}
