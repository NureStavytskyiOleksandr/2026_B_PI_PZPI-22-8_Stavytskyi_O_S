using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SingeEffectUI : MonoBehaviour
{
    [SerializeField] private Image backgroundImage;
    [SerializeField] private Image effectImage;
    [SerializeField] private Image effectImageBack;

    public void Initialize(Sprite effectImage, float effectTime)
    {
        this.effectImage.sprite = effectImage;
        effectImageBack.sprite = effectImage;
        this.effectImage.SetNativeSize();
        effectImageBack.SetNativeSize();

        StartCoroutine(EffectTimerRoutine(effectTime));
    }
    private IEnumerator EffectTimerRoutine(float effectTime)
    {
        float elapsed = 0f;
        backgroundImage.fillAmount = 1f;
        effectImage.fillAmount = 1f;

        while (elapsed < effectTime)
        {
            elapsed += Time.deltaTime;
            backgroundImage.fillAmount = 1f - (elapsed / effectTime);
            effectImage.fillAmount = 1f - (elapsed / effectTime);
            yield return null;
        }

        backgroundImage.fillAmount = 0f;
        effectImage.fillAmount = 0f;
        Destroy(gameObject);
    }
}
