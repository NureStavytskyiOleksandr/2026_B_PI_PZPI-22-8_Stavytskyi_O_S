using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillGroupLevelingUI : MonoBehaviour
{
    [SerializeField] private SingleSkillLevelingUI[] skills; 

    public void Show()
    {
        UpdateSkillGroup();

        gameObject.SetActive(true);
    }
    public void Hide()
    {
        gameObject.SetActive(false);
    }

    public void UpdateSkillGroup()
    {
        foreach (SingleSkillLevelingUI skill in skills)
        {
            skill.UpdateSkillInfo();
        }
    }
}
