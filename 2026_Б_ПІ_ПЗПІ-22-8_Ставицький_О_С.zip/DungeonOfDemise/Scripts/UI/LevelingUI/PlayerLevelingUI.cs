using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PlayerLevelingUI : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI characteristicPoints;
    [SerializeField] private SingleCharacteristicPlayerLevelingUI[] singleCharsUIs;

    private void Start()
    {
        PlayerCharacteristics.Instance.OnCharacteristicPointChanged += PlayerCharacteristics_OnCharacteristicPointChanged;
        UpdateCharacteristicPointsText();
    }

    private void PlayerCharacteristics_OnCharacteristicPointChanged(object sender, System.EventArgs e)
    {
        UpdateCharacteristicPointsText();
    }

    private void UpdateCharacteristicPointsText()
    {
        characteristicPoints.text = PlayerCharacteristics.Instance.GetCharacteristicPoints().ToString();
    }

    public void Show()
    {
        UpdateCharacteristicPointsText();
        foreach(SingleCharacteristicPlayerLevelingUI singleCharsUI in singleCharsUIs)
        {
            singleCharsUI.UpdateUI();
        }
        gameObject.SetActive(true);
    }
    public void Hide()
    {
        gameObject.SetActive(false);
    }
}
