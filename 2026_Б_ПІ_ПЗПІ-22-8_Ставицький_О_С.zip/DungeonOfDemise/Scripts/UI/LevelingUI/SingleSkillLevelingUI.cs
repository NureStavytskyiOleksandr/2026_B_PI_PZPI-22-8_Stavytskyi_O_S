using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SingleSkillLevelingUI : MonoBehaviour
{
    [SerializeField] private Button levelingButton;
    [SerializeField] private Image skillImage;
    [SerializeField] private Button skillButton;
    [SerializeField] private Image skillLevelImage;

    [Space(5)]
    [SerializeField] private Sprite[] levels;
    [SerializeField] private ChooseSkillSlotLevelingUI chooseSlotUIPrefab;

    [Space(5)]
    [SerializeField] private int skillID;
    private void Start()
    {
        levelingButton.onClick.AddListener(() =>
        {
            SkillManager.Instance.UpgradeSkill(skillID);
            //PlayerStats.Instance.SubtractSkillPoints();
            PlayerCharacteristics.Instance.SubtractSkillPoints();
        });

        skillButton.onClick.AddListener(() =>
        {
            ChooseSkillSlotLevelingUI chooseSkillSlotLevelingUI = Instantiate(chooseSlotUIPrefab, transform.root);

            chooseSkillSlotLevelingUI.Initialize(skillID);
        });

        //PlayerStats.Instance.OnSkillPointChanged += PlayerStats_OnSkillPointChanged;
        PlayerCharacteristics.Instance.OnSkillPointChanged += PlayerStats_OnSkillPointChanged;
    }

    private void PlayerStats_OnSkillPointChanged(object sender, System.EventArgs e)
    {
        UpdateSkillInfo();
    }

    public void UpdateSkillInfo()
    {
        SkillHandler skillHandler = SkillManager.Instance.GetSkillHandlerData(skillID);

        //levelingButton.gameObject.SetActive(PlayerStats.Instance.GetSkillPoints() > 0 && skillHandler.skillLevel < 3);
        levelingButton.gameObject.SetActive(PlayerCharacteristics.Instance.GetSkillPoints() > 0 && skillHandler.skillLevel < 3);

        skillImage.sprite = skillHandler.skillSO.skillImage;
        //skillImage.color = skillHandler.skillLevel > 0 ? Color.white : Color.grey;
        skillButton.interactable = skillHandler.skillLevel > 0 ? true : false;

        skillLevelImage.sprite = levels[skillHandler.skillLevel];
    }
}
