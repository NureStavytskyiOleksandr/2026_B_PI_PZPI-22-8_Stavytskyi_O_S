using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SingleCharacteristicPlayerLevelingUI : MonoBehaviour
{
    [SerializeField] private Characteristic.CharacteristicType characteristicType;
    [SerializeField] private Button upgradeButton;
    [SerializeField] private TextMeshProUGUI characteristicText;
    [SerializeField] private string measure;

    private void Start()
    {
        upgradeButton.onClick.AddListener(() =>
        {
            PlayerCharacteristics.Instance.UpgradeBaseCharacteristic(characteristicType);
        });

        PlayerCharacteristics.Instance.OnCharacteristicPointChanged += PlayerCharacteristics_OnCharacteristicPointChanged;
        PlayerCharacteristics.Instance.OnCharacteristicsChanged += PlayerCharacteristics_OnCharacteristicsChanged;

        UpdateUI();
    }

    private void PlayerCharacteristics_OnCharacteristicsChanged(object sender, System.EventArgs e)
    {
        UpdateUI();
    }

    private void PlayerCharacteristics_OnCharacteristicPointChanged(object sender, System.EventArgs e)
    {
        UpdateUI();
    }

    public void UpdateUI()
    {
        characteristicText.text = $"{PlayerCharacteristics.Instance.GetBaseCharacteristicValue(characteristicType)} {measure}";
        upgradeButton.gameObject.SetActive(PlayerCharacteristics.Instance.GetCharacteristicPoints() > 0);
    }
}

