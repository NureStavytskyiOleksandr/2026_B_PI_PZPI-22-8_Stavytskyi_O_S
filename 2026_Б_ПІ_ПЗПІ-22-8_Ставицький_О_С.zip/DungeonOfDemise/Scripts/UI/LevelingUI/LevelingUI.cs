using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class LevelingUI : MonoBehaviour
{
    [SerializeField] private Button closeButton;

    [Header("Skill Leveling")]
    [SerializeField] private Button skillLevelingButton;
    [SerializeField] private SkillLevelingUI skillLevelingMenu;

    [Header("Player Leveling")]
    [SerializeField] private Button playerLevelingButton;
    [SerializeField] private PlayerLevelingUI playerLevelingMenu;

    [Header("Inventory")]
    [SerializeField] private Button inventoryButton;
    [SerializeField] private InventoryUI inventoryMenu;

    private void Awake()
    {
        closeButton.onClick.AddListener(() =>
        {
            Hide();
        });
        skillLevelingButton.onClick.AddListener(() =>
        {
            DisableAllWindows();
            skillLevelingMenu.Show();
        });
        playerLevelingButton.onClick.AddListener(() =>
        {
            DisableAllWindows();
            playerLevelingMenu.Show();
        });
        inventoryButton.onClick.AddListener(() =>
        {
            DisableAllWindows();
            inventoryMenu.Show();
        });
    }

    private void DisableAllWindows()
    {
        skillLevelingMenu.Hide();
        playerLevelingMenu.Hide();
        inventoryMenu.Hide();
    }
    public void Show()
    {
        skillLevelingMenu.UpdateAllGroups();
        inventoryMenu.UpdateInventoryImages();

        gameObject.SetActive(true);
    }
    private void Hide()
    {
        gameObject.SetActive(false);
    }
}
