using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SkillLevelingUI : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI skillPointsText;

    [Header("Swords")]
    [SerializeField] private Button swordButton;
    [SerializeField] private SkillGroupLevelingUI swordsSkillGroup;

    [Header("Lightning")]
    [SerializeField] private Button lightningButton;
    [SerializeField] private SkillGroupLevelingUI lightningSkillGroup;

    [Header("Ice")]
    [SerializeField] private Button iceButton;
    [SerializeField] private SkillGroupLevelingUI iceSkillGroup;

    [Header("Buff")]
    [SerializeField] private Button buffButton;
    [SerializeField] private SkillGroupLevelingUI buffSkillGroup;

    private void Awake()
    {
        swordButton.onClick.AddListener(() =>
        {
            DisableAllWindows();
            swordsSkillGroup.Show();
        });
        lightningButton.onClick.AddListener(() =>
        {   
            DisableAllWindows();
            lightningSkillGroup.Show();
        });
        iceButton.onClick.AddListener(() =>
        {
            DisableAllWindows();
            iceSkillGroup.Show();
        });
        buffButton.onClick.AddListener(() =>
        {
            DisableAllWindows();
            buffSkillGroup.Show();
        });
    }
    private void Start()
    {
        //PlayerStats.Instance.OnSkillPointChanged += PlayerStats_OnSkillPointChanged;
        PlayerCharacteristics.Instance.OnSkillPointChanged += PlayerStats_OnSkillPointChanged;
    }

    private void PlayerStats_OnSkillPointChanged(object sender, System.EventArgs e)
    {
        UpdateSkillPoints();
    }

    private void DisableAllWindows()
    {
        swordsSkillGroup.Hide();
        lightningSkillGroup.Hide();
        iceSkillGroup.Hide();
        buffSkillGroup.Hide();
    }
    public void UpdateAllGroups()
    {
        UpdateSkillPoints();

        swordsSkillGroup.UpdateSkillGroup();
        lightningSkillGroup.UpdateSkillGroup();
        iceSkillGroup.UpdateSkillGroup();
        buffSkillGroup.UpdateSkillGroup();
    }
    private void UpdateSkillPoints()
    {
        //skillPointsText.text = PlayerStats.Instance.GetSkillPoints().ToString();
        skillPointsText.text = PlayerCharacteristics.Instance.GetSkillPoints().ToString();
    }
    public void Show()
    {
        UpdateAllGroups();

        UpdateSkillPoints();

        gameObject.SetActive(true);
    }
    public void Hide()
    {
        gameObject.SetActive(false);
    }
}
