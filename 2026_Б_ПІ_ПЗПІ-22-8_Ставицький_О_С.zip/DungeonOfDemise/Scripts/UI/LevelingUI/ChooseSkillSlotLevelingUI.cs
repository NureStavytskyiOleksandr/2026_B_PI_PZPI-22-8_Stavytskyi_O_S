using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChooseSkillSlotLevelingUI : MonoBehaviour
{
    [Header("1st")]
    [SerializeField] private Button chooseFirstSlotButton;
    [SerializeField] private Image activeFirstSlot;

    [Header("2st")]
    [SerializeField] private Button chooseSecondSlotButton;
    [SerializeField] private Image activeSecondSlot;

    [Header("3st")]
    [SerializeField] private Button chooseThirdSlotButton;
    [SerializeField] private Image activeThirdSlot;

    [Header("Other")]
    [SerializeField] private Button closeButton;
    [SerializeField] private Sprite defaultSkill;

    private int skillID;


    private void Start()
    {
        chooseFirstSlotButton.onClick.AddListener(() =>
        {
            SkillManager.Instance.SetSkill(skillID, 1);
            Hide();
        });
        chooseSecondSlotButton.onClick.AddListener(() =>
        {
            SkillManager.Instance.SetSkill(skillID, 2);
            Hide();
        });
        chooseThirdSlotButton.onClick.AddListener(() =>
        {
            SkillManager.Instance.SetSkill(skillID, 3);
            Hide();
        });
        closeButton.onClick.AddListener(() =>
        {
            Hide();
        });
    }

    public void Initialize(int skillID)
    {
        this.skillID = skillID;

        activeFirstSlot.sprite = SkillManager.Instance.GetSkillHandlerData(SkillManager.Instance.FirstSkillID) != null ? SkillManager.Instance.GetSkillHandlerData(SkillManager.Instance.FirstSkillID).skillSO.skillImage : defaultSkill;
        activeSecondSlot.sprite = SkillManager.Instance.GetSkillHandlerData(SkillManager.Instance.SecondSkillID) != null ? SkillManager.Instance.GetSkillHandlerData(SkillManager.Instance.SecondSkillID).skillSO.skillImage : defaultSkill;
        activeThirdSlot.sprite = SkillManager.Instance.GetSkillHandlerData(SkillManager.Instance.ThirdSkillID) != null ? SkillManager.Instance.GetSkillHandlerData(SkillManager.Instance.ThirdSkillID).skillSO.skillImage : defaultSkill;
    }

    private void Hide()
    {
        InputUI.Instance.UpdateSkillIcons();
        Destroy(gameObject);
    }
}
