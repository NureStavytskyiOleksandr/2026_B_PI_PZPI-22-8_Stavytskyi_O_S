using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SingleShopItemToBuyUI : MonoBehaviour
{
    [SerializeField] private Button itemButton;
    [SerializeField] private Image itemImage;
    [SerializeField] private TextMeshProUGUI itemName;
    [SerializeField] private TextMeshProUGUI itemPrice;

    private ShopItem shopItem;

    private void Start()
    {
        itemButton.onClick.AddListener(() =>
        {
            ShopSystem.Instance.SetBuyItem(shopItem);
        });
    }
    public void Initialize(ShopItem shopItemToSet)
    {
        shopItem = shopItemToSet;
        itemImage.sprite = shopItem.inventoryItem.spriteUI;
        itemImage.SetNativeSize();
        itemName.text = shopItem.inventoryItem.name;
        itemPrice.text = shopItem.price.ToString();
    }
}
