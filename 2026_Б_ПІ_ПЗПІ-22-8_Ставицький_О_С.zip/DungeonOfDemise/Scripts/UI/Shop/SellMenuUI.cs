using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SellMenuUI : MonoBehaviour
{
    [SerializeField] private Image sellerImage;
    [SerializeField] private Button sellButton;
    [SerializeField] private SingleShopInventoryItemUI[] inventoryItems;

    [SerializeField] private Image sellItemBG;
    [SerializeField] private Image priceBG;

    [SerializeField] private Image sellItemImage;
    [SerializeField] private TextMeshProUGUI sellItemAmount;
    [SerializeField] private TextMeshProUGUI priceAmount;

    [SerializeField] private Scrollbar amountScrollbar;

    [SerializeField] private TextMeshProUGUI sellerText;

    private InventorySlot choosedSellInventorySlot;
    private int choosedSellItemAmount;
    private void Start()
    {
        amountScrollbar.onValueChanged.AddListener(amount =>
        {
            int maxAmount = choosedSellInventorySlot.amount;
            choosedSellItemAmount = Mathf.RoundToInt(amount * (maxAmount - 1)) + 1;

            sellItemAmount.text = choosedSellItemAmount.ToString();
            priceAmount.text = (choosedSellItemAmount * ShopSystem.Instance.GetSellItemPrice(choosedSellInventorySlot.item)).ToString();

            if (ShopSystem.Instance.CanSellItem(choosedSellInventorySlot.item))
                sellerText.text = $"�, ���� ���� �����! �������� {choosedSellItemAmount * ShopSystem.Instance.GetSellItemPrice(choosedSellInventorySlot.item)} �����.";
        });
        sellButton.onClick.AddListener(() =>
        {
            int amount = choosedSellItemAmount * ShopSystem.Instance.GetSellItemPrice(choosedSellInventorySlot.item);
            PlayerCharacteristics.Instance.AddMoney(amount);
            ShopSystem.Instance.SellItem(choosedSellItemAmount);
        });

        ShopSystem.Instance.OnSellItemSelected += ShopSystem_OnSellItemSelected;
        InventorySystem.Instance.OnInventoryChanged += InventorySystem_OnInventoryChanged;

    }
    private void InventorySystem_OnInventoryChanged(object sender, System.EventArgs e)
    {
        choosedSellInventorySlot = InventorySystem.Instance.GetSlotData(ShopSystem.Instance.SelectedSellItemID);
        choosedSellItemAmount = choosedSellInventorySlot.amount;

        if (choosedSellInventorySlot.item == null)
        {
            SetToDefault();
        }
        else
            UpdateSellMenu();
    }

    private void ShopSystem_OnSellItemSelected(object sender, System.EventArgs e)
    {
        choosedSellInventorySlot = InventorySystem.Instance.GetSlotData(ShopSystem.Instance.SelectedSellItemID);
        choosedSellItemAmount = choosedSellInventorySlot.amount;

        UpdateSellMenu();
    }
    private void UpdateSellMenu()
    {
        if (choosedSellItemAmount > 1)
        {
            choosedSellItemAmount = 1;
            amountScrollbar.gameObject.SetActive(true);
            amountScrollbar.value = 0;
            amountScrollbar.numberOfSteps = choosedSellInventorySlot.amount;
        }
        else if (choosedSellItemAmount == 1)
            amountScrollbar.gameObject.SetActive(false);

        sellItemBG.gameObject.SetActive(true);
        priceBG.gameObject.SetActive(true);

        if (ShopSystem.Instance.CanSellItem(choosedSellInventorySlot.item))
        {
            sellButton.gameObject.SetActive(true);
            sellerText.text = $"�, ���� ���� �����! �������� {choosedSellItemAmount * ShopSystem.Instance.GetSellItemPrice(choosedSellInventorySlot.item)} �����.";
        }
        else
        {
            sellButton.gameObject.SetActive(false);
            sellerText.text = "������, ������ �� �����.";
        }

        sellItemImage.sprite = choosedSellInventorySlot.item.spriteUI;
        sellItemImage.SetNativeSize();
        sellItemAmount.text = choosedSellItemAmount.ToString();

        priceAmount.text = (choosedSellItemAmount * ShopSystem.Instance.GetSellItemPrice(choosedSellInventorySlot.item)).ToString();
    }
    private void SetToDefault()
    {
        amountScrollbar.gameObject.SetActive(false);
        sellItemBG.gameObject.SetActive(false);
        priceBG.gameObject.SetActive(false);
        sellButton.gameObject.SetActive(false);
        sellerText.text = "";
    }
    public void Show()
    {
        foreach (var item in inventoryItems)
        {
            item.UpdateImage();
        }

        sellerImage.sprite = ShopSystem.Instance.GetSellerImage();

        gameObject.SetActive(true);
    }
    public void Hide()
    {
        SetToDefault();
        gameObject.SetActive(false);
    }

    private void OnDestroy()
    {
        ShopSystem.Instance.OnSellItemSelected -= ShopSystem_OnSellItemSelected;
        InventorySystem.Instance.OnInventoryChanged -= InventorySystem_OnInventoryChanged;
    }
}
