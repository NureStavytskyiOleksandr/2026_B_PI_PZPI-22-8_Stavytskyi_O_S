using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SingleShopInventoryItemUI : MonoBehaviour
{

    [SerializeField] private Button slotButton;
    [SerializeField] private TextMeshProUGUI slotAmountText;
    [SerializeField] private Image image;
    [SerializeField] private int slotIndex;


    private void Start()
    {
        slotButton.onClick.AddListener(() =>
        {
            ShopSystem.Instance.SelectItemToSell(slotIndex);
        });

        InventorySystem.Instance.OnInventoryChanged += PlayerInventory_OnInventoryChanged;
    }

    private void PlayerInventory_OnInventoryChanged(object sender, System.EventArgs e)
    {
        UpdateImage();
    }

    public void UpdateImage()
    {
        if (InventorySystem.Instance.IsSlotOccupied(slotIndex))
        {
            InventorySlot item = InventorySystem.Instance.GetSlotData(slotIndex);
            SetImage(item.item.spriteUI);
            SetText(item.amount);
        }
        else
        {
            DeleteImage();
            slotAmountText.text = "";
        }
    }
    private void SetText(int amount)
    {
        slotAmountText.text = amount > 1 ? amount.ToString() : "";
    }
    private void SetImage(Sprite sprite)
    {
        image.sprite = sprite;
        image.color = Color.white;
        image.SetNativeSize();
    }
    private void DeleteImage()
    {
        image.sprite = null;
        image.color = Color.clear;
    }
    private void OnDestroy()
    {
        InventorySystem.Instance.OnInventoryChanged -= PlayerInventory_OnInventoryChanged;
    }
}
