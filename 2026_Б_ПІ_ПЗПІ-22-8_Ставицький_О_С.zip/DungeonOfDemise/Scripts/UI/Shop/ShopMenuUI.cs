using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ShopMenuUI : MonoBehaviour
{
    [Header("Buttons")]
    [SerializeField] private Button buyMenuButton;
    [SerializeField] private Button sellMenuButton;
    [SerializeField] private TextMeshProUGUI moneyAmountText;
    [SerializeField] private Button closeButton;

    [Header("Menus")]
    [SerializeField] private SellMenuUI sellMenu;
    [SerializeField] private BuyMenuUI buyMenu;


    private void Start()
    {
        buyMenuButton.onClick.AddListener(() =>
        {
            sellMenu.Hide();
            buyMenu.Show();
        });
        sellMenuButton.onClick.AddListener(() =>
        {
            buyMenu.Hide();
            sellMenu.Show();
        });
        closeButton.onClick.AddListener(() =>
        {
            Destroy(gameObject);
        });

        PlayerCharacteristics.Instance.OnMoneyChanged += PlayerCharacteristics_OnMoneyChanged;
    }

    private void PlayerCharacteristics_OnMoneyChanged(object sender, System.EventArgs e)
    {
        moneyAmountText.text = PlayerCharacteristics.Instance.GetMoney().ToString();
    }

    public void Initialize()
    {
        Show();
        moneyAmountText.text = PlayerCharacteristics.Instance.GetMoney().ToString();
        sellMenu.Show();
    }

    private void Show()
    {
        gameObject.SetActive(true);
    }
    private void Hide()
    {
        gameObject.SetActive(false);
    }
    private void OnDestroy()
    {
        PlayerCharacteristics.Instance.OnMoneyChanged -= PlayerCharacteristics_OnMoneyChanged;
    }
}
