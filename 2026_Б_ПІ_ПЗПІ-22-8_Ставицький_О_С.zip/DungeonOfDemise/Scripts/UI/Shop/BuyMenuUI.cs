using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class BuyMenuUI : MonoBehaviour
{
    [SerializeField] private Image sellerImage;
    [SerializeField] private TextMeshProUGUI sellerText;

    [SerializeField] private Image sellItemBG;
    [SerializeField] private Image sellItemImage;
    [SerializeField] private TextMeshProUGUI sellItemAmount;

    [SerializeField] private Image priceBG;
    [SerializeField] private TextMeshProUGUI priceAmount;

    [SerializeField] private Button buyButton;

    [SerializeField] private Scrollbar amountScrollbar;

    [SerializeField] private Transform LayoutForBuyObjects;

    [SerializeField] private SingleShopItemToBuyUI shopItemToBuyPrefab;

    private ShopItem selectedBuyItem;
    private int choosedBuyItemAmount;

    private bool isSpawned = false;

    private void Start()
    {
        amountScrollbar.onValueChanged.AddListener(amount =>
        {
            int maxAmount = selectedBuyItem.inventoryItem.amountMax;
            choosedBuyItemAmount = Mathf.RoundToInt(amount * (maxAmount - 1)) + 1;

            sellItemAmount.text = choosedBuyItemAmount.ToString();
            priceAmount.text = (choosedBuyItemAmount * selectedBuyItem.price).ToString();
        });
        buyButton.onClick.AddListener(() =>
        {
            if (!PlayerCharacteristics.Instance.HasEnoughMoney(choosedBuyItemAmount * selectedBuyItem.price))
                return;

            if (InventorySystem.Instance.HasEnoughSlots(selectedBuyItem.inventoryItem, choosedBuyItemAmount))
            {
                PlayerCharacteristics.Instance.SubtractMoney(choosedBuyItemAmount * selectedBuyItem.price);
                ShopSystem.Instance.BuyItem(choosedBuyItemAmount);
            }
        });
        ShopSystem.Instance.OnBuyItemSelected += ShopSystem_OnBuyItemSelected;
    }

    private void ShopSystem_OnBuyItemSelected(object sender, System.EventArgs e)
    {
        selectedBuyItem = ShopSystem.Instance.SelectedBuyItem;
        choosedBuyItemAmount = 1;

        sellItemBG.gameObject.SetActive(true);
        priceBG.gameObject.SetActive(true);
        buyButton.gameObject.SetActive(true);
        amountScrollbar.gameObject.SetActive(true);

        sellItemImage.sprite = selectedBuyItem.inventoryItem.spriteUI;
        sellItemImage.SetNativeSize();
        sellItemAmount.text = choosedBuyItemAmount.ToString();

        priceAmount.text = (choosedBuyItemAmount * selectedBuyItem.price).ToString();

        amountScrollbar.value = 0;
        amountScrollbar.numberOfSteps = selectedBuyItem.inventoryItem.amountMax;

        sellerText.text = selectedBuyItem.inventoryItem.aboutItem;
    }
    private void SetToDefault()
    {
        amountScrollbar.gameObject.SetActive(false);
        sellItemBG.gameObject.SetActive(false);
        priceBG.gameObject.SetActive(false);
        buyButton.gameObject.SetActive(false);
        sellerText.text = "";
    }

    public void Show()
    {
        if (!isSpawned)
        {
            ShopItem[] shopItems = ShopSystem.Instance.GetBuyItems();

            foreach (var shopItem in shopItems)
            {
                SingleShopItemToBuyUI spawnedObject = Instantiate(shopItemToBuyPrefab, LayoutForBuyObjects);
                spawnedObject.Initialize(shopItem);
            }

            isSpawned = true;
        }

        sellerImage.sprite = ShopSystem.Instance.GetSellerImage();

        gameObject.SetActive(true);
    }
    public void Hide()
    {
        SetToDefault();

        gameObject.SetActive(false);
    }
    private void OnDestroy()
    {
        ShopSystem.Instance.OnBuyItemSelected -= ShopSystem_OnBuyItemSelected;
    }
}
