using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.OnScreen;

public class JoystickActivator : MonoBehaviour
{
    [Header("ActivationZone")]
    [SerializeField] private Vector2 activationZoneSize = new Vector2(400, 400);
    [SerializeField] private Vector2 activationZoneOffset = new Vector2(0, 0);

    [Header("Stick")]
    [SerializeField] private RectTransform joystickTransform;
    [SerializeField] private Canvas canvas;

    [Header("OnScreenStick")]
    [SerializeField] private OnScreenStick onScreenStick;

    private int activeTouchId = -1;

    void Update()
    {
        if (Input.touchCount > 0)
        {
            for (int i = 0; i < Input.touchCount; i++)
            {
                Touch touch = Input.GetTouch(i);
                Vector2 touchPos = touch.position;

                if (touch.phase == TouchPhase.Began)
                {
                    if (activeTouchId == -1 && IsInActivationZone(touchPos))
                    {
                        activeTouchId = touch.fingerId;
                        ShowJoystick(touchPos);

                        if (onScreenStick != null)
                        {
                            var pointerData = new PointerEventData(EventSystem.current) { position = touchPos };
                            onScreenStick.OnPointerDown(pointerData);
                        }
                    }
                }
                else if (touch.fingerId == activeTouchId)
                {
                    if (touch.phase == TouchPhase.Moved || touch.phase == TouchPhase.Stationary)
                    {
                        if (onScreenStick != null)
                        {
                            var pointerData = new PointerEventData(EventSystem.current) { position = touchPos };
                            onScreenStick.OnDrag(pointerData);
                        }
                    }
                    else if (touch.phase == TouchPhase.Ended || touch.phase == TouchPhase.Canceled)
                    {
                        if (onScreenStick != null)
                        {
                            var pointerData = new PointerEventData(EventSystem.current) { position = touchPos };
                            onScreenStick.OnPointerUp(pointerData);
                        }

                        // �� ������ ��������
                        // HideJoystick();

                        // ��� ������� �������� �����, ��� ����� ���� ���������� �������� �����
                        activeTouchId = -1;
                    }
                }
            }
        }
    }

    bool IsInActivationZone(Vector2 screenPos)
    {
        Vector2 min = activationZoneOffset;
        Vector2 max = activationZoneOffset + activationZoneSize;
        return screenPos.x >= min.x && screenPos.x <= max.x &&
               screenPos.y >= min.y && screenPos.y <= max.y;
    }

    void ShowJoystick(Vector2 screenPos)
    {
        Vector2 localPoint;
        RectTransform canvasRect = canvas.transform as RectTransform;

        if (RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRect, screenPos, canvas.worldCamera, out localPoint))
        {
            joystickTransform.localPosition = localPoint;
            joystickTransform.gameObject.SetActive(true);
        }
    }

    void HideJoystick()
    {
        joystickTransform.gameObject.SetActive(false);
    }

    private void OnDrawGizmosSelected()
    {
        if (canvas == null) return;

        RectTransform canvasRect = canvas.transform as RectTransform;

        Vector3 worldBL, worldTR;
        RectTransformUtility.ScreenPointToWorldPointInRectangle(canvasRect, activationZoneOffset, canvas.worldCamera, out worldBL);
        RectTransformUtility.ScreenPointToWorldPointInRectangle(canvasRect, activationZoneOffset + activationZoneSize, canvas.worldCamera, out worldTR);

        Gizmos.color = new Color(0f, 1f, 0f, 0.25f);
        Gizmos.DrawCube((worldBL + worldTR) / 2f, worldTR - worldBL);
    }
}