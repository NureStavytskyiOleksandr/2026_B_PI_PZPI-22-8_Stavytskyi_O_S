using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class DialogueOptionSingleUI : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI optionText;

    private DialogueOption dialogueOption;

    private void Awake()
    {
        GetComponent<Button>().onClick.AddListener(() =>
        {
            DialogueManager.Instance.NextLine(dialogueOption.nextLine);
        });
    }
    public void SetText(DialogueOption dialogueOptionToSet)
    {
        dialogueOption = dialogueOptionToSet;
        optionText.text = dialogueOption.textLine;
    }
}
