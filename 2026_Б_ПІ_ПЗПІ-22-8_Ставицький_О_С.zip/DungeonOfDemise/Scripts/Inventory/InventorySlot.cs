using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class InventorySlot
{
    public InventoryItem item;
    public InventoryItem.ItemType slotType;
    public int amount;
    
    public InventorySlot(InventoryItem.ItemType slotType)
    {
        this.slotType = slotType;
    }
    public void SetItem(InventoryItem itemToSet)
    {
        if(IsFree())
        {
            item = itemToSet;
            amount = 1;
        }
    }
    public void UseItem()
    {
        if(item != null)
            item.UseEffects();
    }

    public bool IsFree()
    {
        return item == null;
    }
}