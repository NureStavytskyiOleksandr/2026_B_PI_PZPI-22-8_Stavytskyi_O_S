using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LootItem : MonoBehaviour, IInteractable
{
    [SerializeField] private InventoryItem inventoryItem;

    public void Interact()
    {
        InventorySystem.Instance.SetItem(inventoryItem);
        Destroy(gameObject);
    }
}
