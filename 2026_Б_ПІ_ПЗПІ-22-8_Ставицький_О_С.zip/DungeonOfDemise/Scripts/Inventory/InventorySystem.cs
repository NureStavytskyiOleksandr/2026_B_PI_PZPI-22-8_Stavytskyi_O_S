using System;
using System.Collections.Generic;
using UnityEngine;

public class InventorySystem : MonoBehaviour
{
    public static InventorySystem Instance;

    [SerializeField] private InventorySlot[] inventorySlots;

    public event EventHandler OnInventoryChanged;
    public event EventHandler OnEquipmentChanged;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
    }

    public void SetItem(InventoryItem item)
    {
        if (HasFreeSlots())
        {
            if (HasSameItem(item) >= 0)
            {

                inventorySlots[HasSameItem(item)].amount++;
            }
            else
            {
                inventorySlots[FirstFreeSlot()].SetItem(item);
            }
            OnInventoryChanged?.Invoke(this, EventArgs.Empty);
        }
    }
    private bool IsEquip(InventoryItem.ItemType type)
    {
        return type == InventoryItem.ItemType.EquipHelmet || type == InventoryItem.ItemType.EquipArmor || type == InventoryItem.ItemType.EquipBoots;
    }
    public List<InventoryItem> GetEquipment()
    {
        List<InventoryItem> result = new List<InventoryItem>();
        foreach(InventorySlot inventorySlot in inventorySlots)
        {
            if(IsEquip(inventorySlot.slotType))
            {
                if (inventorySlot.item != null)
                {
                    if(inventorySlot.item.effects != null)
                    {
                        result.Add(inventorySlot.item);
                    }
                }
            }
        }
        return result;
    }
    public Sprite GetItemSprite(int slotId)
    {
        return inventorySlots[slotId].item != null ? inventorySlots[slotId].item.spriteUI : null;
    }
    public InventoryItem GetItemData(int slotId)
    {
        return inventorySlots[slotId].item != null ? inventorySlots[slotId].item : null;
    }   
    public void UseItemInSlot(int slotId)
    {
        inventorySlots[slotId].UseItem();
        inventorySlots[slotId].amount--;
        if (inventorySlots[slotId].amount <= 0)
        {
            inventorySlots[slotId] = new InventorySlot(inventorySlots[slotId].slotType);
        }
        OnInventoryChanged?.Invoke(this, EventArgs.Empty);
    }
    public InventorySlot GetSlotData(int slotId)
    {
        return inventorySlots[slotId] != null ? inventorySlots[slotId] : null;
    }
    public void SwitchSlot(int startSlot, int finishSlot)
    {
        if (inventorySlots[finishSlot].IsFree())
        {
            InventoryItem.ItemType type = inventorySlots[finishSlot].slotType;
            inventorySlots[finishSlot] = inventorySlots[startSlot];

            inventorySlots[startSlot] = new InventorySlot(inventorySlots[startSlot].slotType);
            inventorySlots[finishSlot].slotType = type;

            if (IsEquip(inventorySlots[startSlot].slotType) ||
               IsEquip(inventorySlots[finishSlot].slotType))
            {
                OnEquipmentChanged?.Invoke(this, EventArgs.Empty);
            }
            OnInventoryChanged?.Invoke(this, EventArgs.Empty);
        }
    }
    public void SwitchTwoSlots(int startSlot, int finishSlot)
    {
        if(inventorySlots[startSlot].item == inventorySlots[finishSlot].item)
        {
            if (inventorySlots[finishSlot].amount < inventorySlots[finishSlot].item.amountMax)
            {
                int totalAmount = inventorySlots[startSlot].amount + inventorySlots[finishSlot].amount;

                inventorySlots[finishSlot].amount = totalAmount >= inventorySlots[finishSlot].item.amountMax ? inventorySlots[finishSlot].item.amountMax : totalAmount;

                inventorySlots[startSlot].amount = totalAmount - inventorySlots[finishSlot].amount;
                if (inventorySlots[startSlot].amount <= 0)
                    inventorySlots[startSlot] = new InventorySlot(inventorySlots[startSlot].slotType);
            }
            else
            {
                InventorySlot slot = inventorySlots[finishSlot];
                InventoryItem.ItemType type = inventorySlots[startSlot].slotType;

                inventorySlots[finishSlot] = inventorySlots[startSlot];
                inventorySlots[finishSlot].slotType = slot.slotType;

                inventorySlots[startSlot] = slot;
                inventorySlots[startSlot].slotType = type;

                if (IsEquip(inventorySlots[startSlot].slotType) ||
                    IsEquip(inventorySlots[finishSlot].slotType))
                {
                    OnEquipmentChanged?.Invoke(this, EventArgs.Empty);
                }
            }

        }
        else
        {
            InventorySlot slot = inventorySlots[finishSlot];
            InventoryItem.ItemType type = inventorySlots[startSlot].slotType;

            inventorySlots[finishSlot] = inventorySlots[startSlot];
            inventorySlots[finishSlot].slotType = slot.slotType;

            inventorySlots[startSlot] = slot;
            inventorySlots[startSlot].slotType = type;
            if (IsEquip(inventorySlots[startSlot].slotType) ||
                IsEquip(inventorySlots[finishSlot].slotType))
            {
                OnEquipmentChanged?.Invoke(this, EventArgs.Empty);
            }
        }
        OnInventoryChanged?.Invoke(this, EventArgs.Empty);
    }
    public bool HasFreeSlots()
    {
        bool result = false;
        foreach (InventorySlot slot in inventorySlots)
        {
            if (slot.IsFree())
            {
                result = true;
                break;
            }
        }
        return result;
    }
    public int HasSameItem(InventoryItem newItem)
    {
        int result = -1;

        for (int i = 0; i < inventorySlots.Length; i++)
        {
            if (!inventorySlots[i].IsFree() && 
                inventorySlots[i].item == newItem && 
                inventorySlots[i].amount < inventorySlots[i].item.amountMax)
            {
                result = i;
                break;
            }
        }
        return result;
    }
    public bool HasEnoughSlots(InventoryItem itemToCheck, int amount)
    {
        int count = 0;
        for (int i = 0; i < inventorySlots.Length; i++)
        {
            if (inventorySlots[i].IsFree())
            {
                count += itemToCheck.amountMax;
            }
            else if (!inventorySlots[i].IsFree() &&
                inventorySlots[i].item == itemToCheck &&
                inventorySlots[i].amount < inventorySlots[i].item.amountMax)
            {
                count += inventorySlots[i].item.amountMax - inventorySlots[i].amount;
            }
            if(count >= amount)
            {
                return true;
            }
        }
        return false;
    }
    public bool IsSlotOccupied(int slotId)
    {
        return !inventorySlots[slotId].IsFree();
    }
    private int FirstFreeSlot()
    {
        int result = -1;
        for(int i = 0; i < inventorySlots.Length; i++)
        {
            if (inventorySlots[i].IsFree())
            {
                result = i;
                break;
            }
        }
        return result;
    }
    public void SubstractItemsFromSlot(int slotId, int amount)
    {
        if(inventorySlots[slotId].amount > amount)
        {
            inventorySlots[slotId].amount -= amount;
        }
        else if(inventorySlots[slotId].amount == amount)
        {
            inventorySlots[slotId] = new InventorySlot(inventorySlots[slotId].slotType);
        }
        OnInventoryChanged?.Invoke(this, EventArgs.Empty);
    }

    public void Save(ref InventorySystemData data)
    {
        data.inventorySlots = inventorySlots;
        Debug.Log("inventory saved");
    }
    public void Load(InventorySystemData data)
    {
        inventorySlots = data.inventorySlots;
        Debug.Log("inventory loaded");
    }
}

[System.Serializable]
public struct InventorySystemData
{
    public InventorySlot[] inventorySlots;
}