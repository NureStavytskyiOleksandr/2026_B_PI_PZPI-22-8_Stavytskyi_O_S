using NavMeshPlus.Components;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class NavMeshManager : MonoBehaviour
{
    public static NavMeshManager Instance;

    NavMeshSurface navMeshSurface;

    private void Start()
    {
        if(Instance == null)
        {
            Instance = this;
        }
        navMeshSurface = GetComponent<NavMeshSurface>();
    }
    public void ReBake()
    {
        navMeshSurface.BuildNavMesh();
    }
}
