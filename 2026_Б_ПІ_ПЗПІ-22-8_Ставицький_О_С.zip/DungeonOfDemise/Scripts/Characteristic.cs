using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Characteristic
{
    public CharacteristicType type;
    public float value;


    public enum CharacteristicType
    {
        maxHeath,
        health,
        maxMana,
        mana,
        attackSpeed,
        magicPower,
        blockingDamage,
        armor,
        magicResistance,
        effectResistance,
        moveSpeed
    }
}