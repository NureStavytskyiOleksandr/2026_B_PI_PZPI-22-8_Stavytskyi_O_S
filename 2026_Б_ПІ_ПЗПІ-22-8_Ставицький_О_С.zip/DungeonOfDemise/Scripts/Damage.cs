using System;

[Serializable]
public class Damage
{
    public enum DamageType
    {
        Physical,
        Magical
    }

    public DamageType damageType;
    public float damageAmount;

    public Damage Clone()
    {
        return new Damage
        {
            damageType = this.damageType,
            damageAmount = this.damageAmount
        };
    }
}