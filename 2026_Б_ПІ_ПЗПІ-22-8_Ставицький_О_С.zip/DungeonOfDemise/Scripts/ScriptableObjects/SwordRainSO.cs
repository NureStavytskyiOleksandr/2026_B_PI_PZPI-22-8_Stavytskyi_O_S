using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "NewSwordRainSO", menuName = "ScriptableObjects/Skills/SwordRainSO")]
public class SwordRainSO : SkillSO
{

    public SwordRainLevel[] levels;

    public override void Activate(Transform skillSpawnPos, int skillLevel)
    {
        SwordRain swordRain = Instantiate(skillPrefab, skillSpawnPos.position, Quaternion.identity).GetComponent<SwordRain>();
        Transform targetPosition = PlayerCombat.Instance.GetTargetEnemy();

        if (targetPosition != null)
        {
            //swordRain.GetComponent<SwordRain>().Initialize(targetPosition.position, levels[skillLevel - 1], PlayerStats.Instance.GetMagicPower());
            swordRain.GetComponent<SwordRain>().Initialize(targetPosition.position, levels[skillLevel - 1], PlayerCharacteristics.Instance.GetChangedCharacteristicValue(Characteristic.CharacteristicType.magicPower));
        }
        else
        {
            //swordRain.GetComponent<SwordRain>().Initialize((Vector2)skillSpawnPos.position + PlayerMovement.Instance.GetLookDirection(), levels[skillLevel - 1], PlayerStats.Instance.GetMagicPower());
            swordRain.GetComponent<SwordRain>().Initialize((Vector2)skillSpawnPos.position + PlayerMovement.Instance.GetLookDirection(), levels[skillLevel - 1], PlayerCharacteristics.Instance.GetChangedCharacteristicValue(Characteristic.CharacteristicType.magicPower));
        }
    }
}

[System.Serializable]
public class SwordRainLevel
{
    public float manaCost;
    public float cooldown;
    public Damage damage;
}
