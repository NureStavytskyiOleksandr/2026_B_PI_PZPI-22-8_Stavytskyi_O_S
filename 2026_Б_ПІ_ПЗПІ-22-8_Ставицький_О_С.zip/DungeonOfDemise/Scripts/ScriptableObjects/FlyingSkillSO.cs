using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "NewFlyingSkillSO", menuName = "ScriptableObjects/Skills/FlyingSkillSO")]
public class FlyingSkillSO : SkillSO
{
    public FlyingSkillLevel[] flyingSkilllevels;

    public override void Activate(Transform skillSpawnPos, int skillLevel)
    {
        FlyingSkill flyingSkill = Instantiate(skillPrefab, skillSpawnPos.position, Quaternion.identity).GetComponent<FlyingSkill>();
        Transform targetPosition = PlayerCombat.Instance.GetTargetEnemy();

        if (targetPosition != null)
        {
            flyingSkill.Initialize(targetPosition.position, flyingSkilllevels[skillLevel - 1], PlayerCharacteristics.Instance.GetChangedCharacteristicValue(Characteristic.CharacteristicType.magicPower));
        }
        else
        {
            flyingSkill.Initialize((Vector2)skillSpawnPos.position + PlayerMovement.Instance.GetLookDirection(), flyingSkilllevels[skillLevel - 1], PlayerCharacteristics.Instance.GetChangedCharacteristicValue(Characteristic.CharacteristicType.magicPower));
        }
    }
}
[System.Serializable]
public class FlyingSkillLevel
{
    public Damage damage;
    public float flySpeed;
    public float maxDistance;
}