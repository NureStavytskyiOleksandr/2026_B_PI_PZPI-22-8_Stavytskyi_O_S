using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewPlayerСharacteristicsConfigSO", menuName = "ScriptableObjects/PlayerСharacteristicsConfigSO")]
public class PlayerСharacteristicsConfigSO : ScriptableObject
{
    [Header("StartCharacteristics")]
    public float moveSpeed;

    [Space(5)]
    public float health;
    public float effectsResistance;
    public float blockingDamage;

    public float attackSpeed;
    public float armor;

    public float mana;
    public float magicResistance;
    public float magicPower;

    [Header("CharacteristicsIncrement")]
    public float healthIncrement;
    public float effectsResistanceIncrement;
    public float blockingDamageIncrement;

    public float attackSpeedIncrement;
    public float armorIncrement;

    public float manaIncrement;
    public float magicResistanceIncrement;
    public float magicPowerIncrement;

    [Header("Experience")]
    public float startTargetExperience;
    public float targetExperienceIncrement;

    public float GetCharacteristicInctement(Characteristic.CharacteristicType characteristicType)
    {
        switch (characteristicType)
        {
            case Characteristic.CharacteristicType.maxHeath:
                return healthIncrement;
            case Characteristic.CharacteristicType.effectResistance:
                return effectsResistanceIncrement;
            case Characteristic.CharacteristicType.blockingDamage:
                return blockingDamageIncrement;
            case Characteristic.CharacteristicType.attackSpeed:
                return attackSpeedIncrement;
            case Characteristic.CharacteristicType.armor:
                return armorIncrement;
            case Characteristic.CharacteristicType.maxMana:
                return manaIncrement;
            case Characteristic.CharacteristicType.magicResistance:
                return magicResistanceIncrement;
            case Characteristic.CharacteristicType.magicPower:
                return magicPowerIncrement;
        }
        return 0;
    }
}
