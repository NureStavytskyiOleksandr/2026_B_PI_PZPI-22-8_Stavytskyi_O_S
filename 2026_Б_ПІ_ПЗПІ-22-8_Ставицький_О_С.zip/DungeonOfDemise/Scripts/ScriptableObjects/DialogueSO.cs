using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewDialogueSO", menuName = "ScriptableObjects/DialogueSO")]
[System.Serializable]
public class DialogueSO : ScriptableObject
{
    public string npcName;

    public Sprite npcFace;

    public DialogueLine[] lines;
}


[System.Serializable]
public class DialogueLine
{
    [TextArea(3, 5)] public string textLine;

    public WhosTalking whosTalking;

    public int nextLine;

    public bool hasOptions;

    public DialogueOption[] options;

    public enum WhosTalking
    {
        Player,
        NPC
    }
}

[System.Serializable]
public class DialogueOption
{
    [TextArea(3, 5)] public string textLine;

    public int nextLine;
}