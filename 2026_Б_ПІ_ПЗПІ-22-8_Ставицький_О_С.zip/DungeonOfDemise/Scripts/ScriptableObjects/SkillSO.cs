using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public abstract class SkillSO : ScriptableObject
{
    public string skillName;

    public Sprite skillImage;

    public Skill skillPrefab;

    public SkillLevel[] generalLevels;

    public abstract void Activate(Transform skillSpawnPos, int skillLevel);
}

[System.Serializable]
public class SkillLevel
{
    public float manaCost;
    public float cooldown;
}