using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "NewDamageInZoneSkillSO", menuName = "ScriptableObjects/Skills/DamageInZoneSkillSO")]
public class DamageInZoneSkillSO : SkillSO
{
    public DamageInZoneLevel[] damageInZonelevels;

    public override void Activate(Transform skillSpawnPos, int skillLevel)
    {
        DamageInZoneSkill damageInZoneSkill = Instantiate(skillPrefab, skillSpawnPos.position, Quaternion.identity).GetComponent<DamageInZoneSkill>();
        Transform targetPosition = PlayerCombat.Instance.GetTargetEnemy();

        if (targetPosition != null)
        {
            //swordRain.Initialize(targetPosition.position, damageInZonelevels[skillLevel - 1], PlayerStats.Instance.GetMagicPower());
            damageInZoneSkill.Initialize(targetPosition.position, damageInZonelevels[skillLevel - 1], PlayerCharacteristics.Instance.GetChangedCharacteristicValue(Characteristic.CharacteristicType.magicPower));
        }
        else
        {
            //swordRain.Initialize((Vector2)skillSpawnPos.position + PlayerMovement.Instance.GetLookDirection(), damageInZonelevels[skillLevel - 1], PlayerStats.Instance.GetMagicPower());
            damageInZoneSkill.Initialize((Vector2)skillSpawnPos.position + PlayerMovement.Instance.GetLookDirection(), damageInZonelevels[skillLevel - 1], PlayerCharacteristics.Instance.GetChangedCharacteristicValue(Characteristic.CharacteristicType.magicPower));
        }
    }
}
[System.Serializable]
public class DamageInZoneLevel
{
    public Damage damage;
}