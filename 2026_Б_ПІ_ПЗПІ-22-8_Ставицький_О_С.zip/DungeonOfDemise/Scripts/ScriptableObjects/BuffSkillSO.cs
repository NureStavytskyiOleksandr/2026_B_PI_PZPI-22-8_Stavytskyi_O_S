using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "NewBuffSkillSO", menuName = "ScriptableObjects/Skills/BuffSkillSO")]
public class BuffSkillSO : SkillSO
{
    public BuffSkillLevel[] buffSkilllevels;

    public override void Activate(Transform skillSpawnPos, int skillLevel)
    {
        Transform targetPosition = PlayerCharacteristics.Instance.gameObject.transform;
        BuffSkill buffSkill = Instantiate(skillPrefab, targetPosition).GetComponent<BuffSkill>();

        if (targetPosition != null)
        {
            buffSkill.Initialize(targetPosition.position, buffSkilllevels[skillLevel - 1], PlayerCharacteristics.Instance.GetChangedCharacteristicValue(Characteristic.CharacteristicType.magicPower));
        }
    }
}
[System.Serializable]
public class BuffSkillLevel
{
    public Effect[] effects;
}