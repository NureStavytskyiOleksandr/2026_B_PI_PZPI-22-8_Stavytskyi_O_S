using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

[CreateAssetMenu(fileName = "NewSwordCageSO", menuName = "ScriptableObjects/Skills/SwordCageSO")]
public class SwordCageSO : SkillSO
{
    public SwordCageLevel[] swordCageLevels;

    public override void Activate(Transform skillSpawnPos, int skillLevel)
    {
        SwordCage swordCage = Instantiate(skillPrefab, skillSpawnPos.position, Quaternion.identity).GetComponent<SwordCage>();

        Transform targetPosition = PlayerCombat.Instance.GetTargetEnemy();

        if (targetPosition != null)
        {
            //swordCage.GetComponent<SwordCage>().Initialize(targetPosition.position, swordCageLevels[skillLevel - 1], PlayerStats.Instance.GetMagicPower());
            swordCage.GetComponent<SwordCage>().Initialize(targetPosition.position, swordCageLevels[skillLevel - 1], PlayerCharacteristics.Instance.GetChangedCharacteristicValue(Characteristic.CharacteristicType.magicPower));
        }
        else
        {
            //swordCage.GetComponent<SwordCage>().Initialize((Vector2)skillSpawnPos.position + PlayerMovement.Instance.GetLookDirection(), swordCageLevels[skillLevel - 1], PlayerStats.Instance.GetMagicPower());
            swordCage.GetComponent<SwordCage>().Initialize((Vector2)skillSpawnPos.position + PlayerMovement.Instance.GetLookDirection(), swordCageLevels[skillLevel - 1], PlayerCharacteristics.Instance.GetChangedCharacteristicValue(Characteristic.CharacteristicType.magicPower));
        }
    }
}

[System.Serializable]
public class SwordCageLevel
{
    public float stunTime;
}
