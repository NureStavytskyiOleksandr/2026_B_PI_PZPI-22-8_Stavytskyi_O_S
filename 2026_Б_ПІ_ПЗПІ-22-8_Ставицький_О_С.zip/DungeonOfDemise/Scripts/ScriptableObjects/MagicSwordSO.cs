using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewMagicSwordSO", menuName = "ScriptableObjects/Skills/MagicSwordSO")]
public class MagicSwordSO : SkillSO
{

    public MagicSwordLevel[] levels;

    public override void Activate(Transform skillSpawnPos, int skillLevel)
    {
        MagicSword sword = Instantiate(skillPrefab, skillSpawnPos.position, Quaternion.identity).GetComponent<MagicSword>();
        Transform targetPosition = PlayerCombat.Instance.GetTargetEnemy();

        if (targetPosition != null)
        {
            //sword.Initialize(targetPosition.position, levels[skillLevel - 1], PlayerStats.Instance.GetMagicPower());
            sword.Initialize(targetPosition.position, levels[skillLevel - 1], PlayerCharacteristics.Instance.GetChangedCharacteristicValue(Characteristic.CharacteristicType.magicPower));
        }
        else
        {
            //sword.Initialize((Vector2)skillSpawnPos.position + PlayerMovement.Instance.GetLookDirection(), levels[skillLevel - 1], PlayerStats.Instance.GetMagicPower());
            sword.Initialize((Vector2)skillSpawnPos.position + PlayerMovement.Instance.GetLookDirection(), levels[skillLevel - 1], PlayerCharacteristics.Instance.GetChangedCharacteristicValue(Characteristic.CharacteristicType.magicPower));
        }
    }
}
[System.Serializable]
public class MagicSwordLevel
{
    public float manaCost;
    public float cooldown;
    public Damage damage;
    public float flySpeed;
    public float maxDistance;
}