using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlimeJumperAnimator : MonoBehaviour
{
    [SerializeField] private SlimeJumper slimeJumper;

    public void CauseDamage()
    {
        slimeJumper.CauseDamage();
    }
    public void JumoToTarget()
    {
        slimeJumper.JumpToTarget();
    }
}
