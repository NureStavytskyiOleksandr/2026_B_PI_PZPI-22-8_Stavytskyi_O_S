using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

[RequireComponent(typeof(Rigidbody2D))]
public abstract class Enemy : MonoBehaviour, IDamageable, IDropItems
{
    [Header("Monster Settings")]
    [SerializeField] private float maxHealth;
    [SerializeField] protected LootItem[] dropableItems;
    [SerializeField] protected float itemsDropRadius;
    [SerializeField] protected int monsterLevel;

    [Header("Movement Settings")]
    [SerializeField] protected float moveSpeed;

    [Space(5)]
    [SerializeField] protected float followRadius;
    [SerializeField] protected float detectionRadius;
    [SerializeField] protected float attackRadius;

    [Space(5)]
    [SerializeField] private float waitTimeBeforeGoingHome;

    [Space(5)]
    [SerializeField] protected LayerMask attackLayer;
    [SerializeField] private LayerMask wallsLayer;

    [Header("Combat Settings")]
    [SerializeField] protected Damage damage;
    [SerializeField] private float delayBetweenAttacks;

    [Header("Other")]
    [SerializeField] private Slider healthSlider;
    [SerializeField] private Animator animator;

    [Header("Exp")]
    [SerializeField] private float sensitivityToLevelDifferences = 5f;
    [SerializeField] private float levelingSpeed = 10f;
    [SerializeField] private float mMin = 0.1f;
    [SerializeField] private float mMax = 2f;


    private const string ATTACK_TRIGGER = "Attack";
    private const string SEE_ENEMY_BOOL = "SeeEnemy";

    protected float currentHealth;
    private Stages currentStage = Stages.Idle;

    private Vector3 lastSeeTargetPos;
    private Vector3 homePos;
    protected Vector2 lastLookDirection;

    protected Transform target;

    private bool canAttack = true;
    private bool isSearching = false;

    private bool isStunned = false;

    private NavMeshAgent agent;
    protected Rigidbody2D rb;

    private enum Stages
    {
        Idle,
        Move,
        Search,
        Attack
    }

    private void Start()
    {
        InvokeRepeating("CheckForTarget", 1, 1);

        rb = GetComponent<Rigidbody2D>();

        agent = GetComponent<NavMeshAgent>();
        agent.updateRotation = false;
        agent.updateUpAxis = false;
        agent.speed = moveSpeed;

        homePos = transform.position;

        currentHealth = maxHealth;
        UpdateHealtBar();
    }

    public void CheckForTarget()
    {
        if (target != null)
            return;

        Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, detectionRadius, attackLayer);
        foreach (var collider in colliders)
        {
            if (collider.TryGetComponent<Player>(out var player))
            {
                if (DoesSeeTarget(player.transform))
                {
                    target = player.transform;
                    break;
                }
            }
        }
    }
    private bool DoesSeeTarget(Transform targetTransform)
    {
        Vector2 direction = (targetTransform.position - transform.position).normalized;
        float distance = Vector2.Distance(targetTransform.position, transform.position);
        int combineLayer = attackLayer.value | wallsLayer.value;

        RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, distance, combineLayer);

        if (hit.collider != null)
        {
            return hit.collider.gameObject == targetTransform.gameObject;
        }

        return false;
    }
    private bool isPathBlocked(Vector3 targetPos)
    {
        Vector2 direction = (targetPos - transform.position).normalized;
        float distance = Vector2.Distance(targetPos, transform.position);

        RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, distance, wallsLayer);

        return hit.collider != null;
    }
    private void CheckDistanceToTarget()
    {
        if (target == null)
            return;


        if (Vector2.Distance(transform.position, target.transform.position) <= attackRadius)
        {
            currentStage = Stages.Attack;
        }
        else if (Vector2.Distance(transform.position, target.transform.position) <= followRadius)
        {
            currentStage = Stages.Move;
        }
        else if (Vector2.Distance(transform.position, target.transform.position) > followRadius)
        {
            lastSeeTargetPos = target.position;
            target = null;
            currentStage = Stages.Search;
        }
    }

    void Update()
    {
        if (isStunned)
        {
            return;
        }

        CheckDistanceToTarget();
        switch (currentStage)
        {
            case Stages.Idle:
                IdleHandler();
                break;
            case Stages.Move:
                MoveHandler();
                break;
            case Stages.Attack:
                AttackHandler();
                break;
            case Stages.Search:
                SearchingHandler();
                break;
        }
    }
    private void IdleHandler()
    {
        animator.SetBool(SEE_ENEMY_BOOL, false);
    }

    private void MoveHandler()
    {
        if (target == null)
            return;

        RotateSprite(target.position);


        if (DoesSeeTarget(target))
        {
            animator.SetBool(SEE_ENEMY_BOOL, true);
            agent.SetDestination(target.position);
            lastSeeTargetPos = target.position;
            lastLookDirection = target.position - gameObject.transform.position;
        }
        else
        {
            target = null;
            currentStage = Stages.Search;
        }
    }
    private void AttackHandler()
    {
        if (target == null)
            return;

        agent.SetDestination(transform.position);
        animator.SetBool(SEE_ENEMY_BOOL, false);
        RotateSprite(target.position);
        if (canAttack)
        {
            animator.SetTrigger(ATTACK_TRIGGER);
            StartCoroutine(ExecuteDelayBetweenAttacks());
        }
    }

    private void SearchingHandler()
    {

        if (!isSearching)
            StartCoroutine(SearchingRoutine());

    }
    private IEnumerator SearchingRoutine()
    {
        isSearching = true;

        RotateSprite(lastSeeTargetPos);
        animator.SetBool(SEE_ENEMY_BOOL, true);
        agent.SetDestination(lastSeeTargetPos);

        while (Vector3.Distance(transform.position, lastSeeTargetPos) > 0.2f)
        {
            if (target != null)
            {
                isSearching = false;
                yield break;
            }

            if (isPathBlocked(lastSeeTargetPos))
            {
                agent.isStopped = true;
                break;
            }

            yield return null;
        }
        animator.SetBool(SEE_ENEMY_BOOL, false);

        yield return new WaitForSeconds(waitTimeBeforeGoingHome);

        RotateSprite(homePos);
        animator.SetBool(SEE_ENEMY_BOOL, true);
        agent.SetDestination(homePos);
        agent.isStopped = false;

        while (Vector3.Distance(transform.position, homePos) > 0.2f)
        {
            if (target != null)
            {
                isSearching = false;
                yield break;
            }
            yield return null;
        }

        animator.SetBool(SEE_ENEMY_BOOL, false);

        currentStage = Stages.Idle;

        isSearching = false;
    }
    private IEnumerator ExecuteDelayBetweenAttacks()
    {
        canAttack = false;

        yield return new WaitForSeconds(delayBetweenAttacks);

        canAttack = true;
    }
    protected void RotateSprite(Vector3 rotateTarget)
    {

        Vector2 moveVector = rotateTarget - transform.position;

        if (moveVector.x < 0)
            transform.localScale = new Vector2(-1, transform.localScale.y);
        else
            transform.localScale = new Vector2(1, transform.localScale.y);
    }
    private IEnumerator StunRoutine(float stunTime)
    {
        isStunned = true;
        animator.enabled = false;
        agent.isStopped = true;

        yield return new WaitForSeconds(stunTime);

        isStunned = false;
        animator.enabled = true;
        agent.isStopped = false;
    }

    public void TakeDamage(Damage damage)
    {
        currentHealth -= damage.damageAmount;
        UpdateHealtBar();
        DeathHandler();
    }

    private void DeathHandler()
    {
        if (currentHealth <= 0)
        {
            GiveExperience();
            DropItems();
            gameObject.SetActive(false);
            //Destroy(gameObject);
        }
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, followRadius);
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, detectionRadius);
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, attackRadius);
    }
    public void ActivateStun(float stunTime)
    {
        StartCoroutine(StunRoutine(stunTime));
    }
    protected void GiveExperience()
    {
        int Lp = PlayerCharacteristics.Instance.GetLevel();
        int Lm = monsterLevel;


        float levelMultiplier = Mathf.Clamp(
            1f + ((Lm - Lp) / sensitivityToLevelDifferences),
            mMin,
            mMax
        );

        float expGained = levelingSpeed * Lm * levelMultiplier;

        expGained = Mathf.Round(expGained * 10f) / 10f;

        PlayerCharacteristics.Instance.GetExperience(Mathf.RoundToInt(expGained));
    }
    protected void UpdateHealtBar()
    {
        if (currentHealth == maxHealth)
        {
            healthSlider.gameObject.SetActive(false);
        }
        else
        {
            healthSlider.gameObject.SetActive(true);
            healthSlider.maxValue = maxHealth;
            healthSlider.value = currentHealth;
        }
    }

    public void DropItems()
    {
        foreach (LootItem item in dropableItems)
        {
            Vector2 randomOffset = Random.insideUnitCircle * itemsDropRadius;

            Vector3 spawnPosition = transform.position + new Vector3(randomOffset.x, randomOffset.y, 0f);
            Instantiate(item, spawnPosition, Quaternion.identity);
        }
    }
}
