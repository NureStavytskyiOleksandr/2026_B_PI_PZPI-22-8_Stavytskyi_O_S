using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class GoblinBoss : Monster, IDamageable
{
    [Header("Settings")]

    [SerializeField] private float maxHealth;
    [SerializeField] private float detectionRadius;

    [SerializeField] private Damage damage;
    [SerializeField] private LayerMask attackLayer;
    [SerializeField] private float delayBetweenAttacks;

    [Header("Jump")]
    [SerializeField] private Vector2 capsuleSizeJump;
    [SerializeField] private Vector2 capsuleOffsetJump;

    [Header("Mace")]
    [SerializeField] private Vector2 capsuleSizeMace;
    [SerializeField] private Vector2 capsuleOffsetMace;


    [Header("Other")]
    [SerializeField] private Slider healthSlider;
    [SerializeField] private Animator animator;
    [SerializeField] private GameEndPortal portal;

    private const string JUMP_ATTACK_TRIGGER = "JumpAttack";
    private const string MACE_ATTACK_TRIGGER = "MaceAttack";

    private Transform target;
    private Stages stage = Stages.Idle;
    private bool canAttack = true;
    private float currentHealth;

    private enum Stages
    {
        Idle,
        Attack
    }

    private void Start()
    {
        InvokeRepeating("CheckForTarget", 1, 1);
        currentHealth = maxHealth;
        UpdateHealtBar();
    }

    public void CheckForTarget()
    {
        if (target != null)
            return;

        Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, detectionRadius, attackLayer);
        foreach (var collider in colliders)
        {
            if (collider.TryGetComponent<Player>(out var player))
            {
                target = player.transform;
                break;
            }
        }
    }

    public void DamageInJumpZone()
    {
        Vector2 center = (Vector2)transform.position + capsuleOffsetJump;

        Collider2D[] hits = Physics2D.OverlapCapsuleAll(
            center,
            capsuleSizeJump,
            CapsuleDirection2D.Horizontal,
            0f,
            attackLayer
        );

        foreach (var hit in hits)
        {
            if (hit.TryGetComponent<IDamageable>(out var damageable))
            {
                damageable.TakeDamage(damage);
            }
        }
    }
    public void DamageInMaceZone()
    {
        Vector2 center = (Vector2)transform.position + capsuleOffsetMace;

        Collider2D[] hits = Physics2D.OverlapCapsuleAll(
            center,
            capsuleSizeMace,
            CapsuleDirection2D.Horizontal,
            0f,
            attackLayer
        );

        foreach (var hit in hits)
        {
            if (hit.TryGetComponent<IDamageable>(out var damageable))
            {
                damageable.TakeDamage(damage);
            }
        }
    }

    void Update()
    {
        if (IsStunned())
        {
            IdleHandler();
            return;
        }

        switch (stage)
        {
            case Stages.Idle:
                IdleHandler();
                break;
            case Stages.Attack:
                AttackHandler();
                break;
        }

        if(target != null)
        {
            if (Vector2.Distance(gameObject.transform.position, target.transform.position) > detectionRadius)
                target = null;
        }
    }
    private void IdleHandler()
    {
        if (target != null)
        {
            stage = Stages.Attack;
        }
    }

    private void AttackHandler()
    {
        if (!canAttack)
        {
            return;
        }
        int random = Random.Range(0, 2);
        if (random == 0)
        {
            animator.SetTrigger(JUMP_ATTACK_TRIGGER);
        }
        else
        {
            animator.SetTrigger(MACE_ATTACK_TRIGGER);
        }
        StartCoroutine(ExecuteDelayBetweenAttacks());

        stage = Stages.Idle;
    }
    private IEnumerator ExecuteDelayBetweenAttacks()
    {
        canAttack = false;

        yield return new WaitForSeconds(delayBetweenAttacks);

        canAttack = true;
    }

    private void UpdateHealtBar()
    {
        if (currentHealth == maxHealth)
        {
            healthSlider.gameObject.SetActive(false);
        }
        else
        {
            healthSlider.gameObject.SetActive(true);
            healthSlider.maxValue = maxHealth;
            healthSlider.value = currentHealth;
        }
    }
    public void TakeDamage(Damage damage)
    {
        currentHealth -= damage.damageAmount;
        UpdateHealtBar();
        DeathHandler();
    }
    private void DeathHandler()
    {
        if (currentHealth <= 0)
        {
            GiveExperience();
            portal.gameObject.SetActive(true);
            gameObject.SetActive(false);
            //Destroy(gameObject);
        }
    }
    void DrawCapsuleGizmoHorizontal(Vector2 center, Vector2 size)
    {

        float radius = size.y / 2f;
        float width = size.x;

        float bodyWidth = width - radius * 2f;

        Vector2 left = center + Vector2.left * (bodyWidth / 2f);
        Vector2 right = center + Vector2.right * (bodyWidth / 2f);

        // ˳�� ����
        Gizmos.DrawWireSphere(left, radius);
        // ����� ����
        Gizmos.DrawWireSphere(right, radius);

        // ���� � ���
        Gizmos.DrawLine(left + Vector2.up * radius, right + Vector2.up * radius);
        Gizmos.DrawLine(left + Vector2.down * radius, right + Vector2.down * radius);
    }


    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, detectionRadius);

        Gizmos.color = Color.red;
        Vector2 center = (Vector2)transform.position + capsuleOffsetJump;
        DrawCapsuleGizmoHorizontal(center, capsuleSizeJump);

        Gizmos.color = Color.blue;
        Vector2 center2 = (Vector2)transform.position + capsuleOffsetMace;
        DrawCapsuleGizmoHorizontal(center2, capsuleSizeMace);
    }


}