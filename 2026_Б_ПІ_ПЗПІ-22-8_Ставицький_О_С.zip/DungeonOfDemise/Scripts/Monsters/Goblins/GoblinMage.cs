using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoblinMage : Enemy
{
    [Header("GoblinMage")]
    [SerializeField] private Transform projectileSpawnPoint;
    [SerializeField] private Arrow projectile;

    public void Attack()
    {
        Arrow arrow = Instantiate(projectile, projectileSpawnPoint.position, Quaternion.identity);
        if (target != null)
            arrow.Initialize(target.position, damage);
    }
    public bool HasTarget()
    {
        return target != null;
    }
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, followRadius);
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, detectionRadius);
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, attackRadius);
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(projectileSpawnPoint.position, 0.1f);
    }
}
