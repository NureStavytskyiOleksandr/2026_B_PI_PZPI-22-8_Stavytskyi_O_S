using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoblinBasicAnimatorEvets : MonoBehaviour
{
    [SerializeField] private GoblinBasic goblinBasic;

    public void Attack()
    {
        goblinBasic.Attack();
    }
}
