using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoblinMageAnimatorEvents : MonoBehaviour
{
    [SerializeField] private GoblinMage goblinMage;

    public void Attack()
    {
        goblinMage.Attack();
    }
}
