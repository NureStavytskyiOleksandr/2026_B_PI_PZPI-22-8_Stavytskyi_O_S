using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoblinBossAnimatorEvents : MonoBehaviour
{
    [SerializeField] private GoblinBoss goblinBoss;

    public void JumpAttack()
    {
        goblinBoss.DamageInJumpZone();
    }
    public void MaceAttack()
    {
        goblinBoss.DamageInMaceZone();
    }
}
