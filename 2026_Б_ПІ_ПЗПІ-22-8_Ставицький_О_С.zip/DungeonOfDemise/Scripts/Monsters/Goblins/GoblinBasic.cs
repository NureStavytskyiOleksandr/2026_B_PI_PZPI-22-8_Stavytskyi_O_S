using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class GoblinBasic : Enemy
{
    [Header("GoblinBasic")]
    [SerializeField] private Transform handlePoint;
    [SerializeField] private EnemyWeapon weapon;

    private void FixedUpdate()
    {
        RotateWeapon();
    }
    public void Attack()
    {
        weapon.StartAttackAnimation(damage, target);
    }
    private void RotateWeapon()
    {
        Vector2 direction = Vector2.zero;

        if (HasTarget())
        {
            direction = (target.position - handlePoint.transform.position).normalized;
        }
        else
        {
            if (gameObject.transform.localScale.x == 1)
                direction = lastLookDirection.normalized;
            else if (gameObject.transform.localScale.x == -1)
                direction = lastLookDirection.normalized * -1;
        }

        if (direction == Vector2.zero)
            return;

        float angle = 0;
        if (gameObject.transform.localScale.x == 1)
        {
            angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        }
        if (gameObject.transform.localScale.x == -1)
        {
            angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg - 180;
        }
        handlePoint.rotation = Quaternion.Euler(0, 0, angle);
    }
    public bool HasTarget()
    {
        return target != null;
    }
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, followRadius);
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, detectionRadius);
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, attackRadius);
    }
}
