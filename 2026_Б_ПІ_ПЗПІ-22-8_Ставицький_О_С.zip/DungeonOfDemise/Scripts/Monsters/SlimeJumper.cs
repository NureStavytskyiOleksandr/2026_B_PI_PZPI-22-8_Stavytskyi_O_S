using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;
using System;

public class SlimeJumper : Enemy
{
    [Header("SlimeJumper")]
    [SerializeField] private float slimeRadius;
    [SerializeField] private float jumpForce;

    //[Header("Settings")]
    //[SerializeField] private float maxHealth;

    //[SerializeField] private float followRadius;
    //[SerializeField] private float detectionRadius;
    //[SerializeField] private float attackRadius;

    //[SerializeField] private float moveSpeed;

    //[SerializeField] private Damage damage;
    //[SerializeField] private LayerMask attackLayer;
    //[SerializeField] private LayerMask wallsLayer;
    //[SerializeField] private float delayBetweenAttacks;
    //[SerializeField] private float waitTimeBeforeGoingHome;


    //[Header("Other")]
    //[SerializeField] private Slider healthSlider;
    //[SerializeField] private Animator animator;


    //private const string ATTACK_TRIGGER = "Attack";
    //private const string SEE_ENEMY_BOOL = "SeeEnemy";

    //private Rigidbody2D rb;
    //private Transform target;
    //private Stages stage = Stages.Idle;
    //private bool canAttack = true;
    //private float currentHealth;
    //private NavMeshAgent agent;
    //private Vector3 homePos;
    //private Vector3 lastSeeTargetPos;
    //private bool isSearching = false;

    //private enum Stages
    //{
    //    Idle,
    //    Move,
    //    Searching,
    //    Attack
    //}

    //private void Start()
    //{
    //    InvokeRepeating("CheckForTarget", 1, 1);

    //    rb = GetComponent<Rigidbody2D>();
    //    agent = GetComponent<NavMeshAgent>();
    //    agent.updateRotation = false;
    //    agent.updateUpAxis = false;
    //    agent.speed = moveSpeed;

    //    homePos = transform.position;

    //    currentHealth = maxHealth;
    //    UpdateHealtBar();
    //}

    //public void CheckForTarget()
    //{
    //    if (target != null)
    //        return;

    //    Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, detectionRadius, attackLayer);
    //    foreach (var collider in colliders)
    //    {
    //        if (collider.TryGetComponent<Player>(out var player))
    //        {
    //            if (DoesSeeTarget(player.transform))
    //            {
    //                target = player.transform;
    //                break;
    //            }
    //        }
    //    }
    //}
    //private bool DoesSeeTarget(Transform targetTransform)
    //{
    //    Vector2 direction = (targetTransform.position - transform.position).normalized;
    //    float distance = Vector2.Distance(targetTransform.position, transform.position);
    //    int combineLayer = attackLayer.value | wallsLayer.value;

    //    RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, distance, combineLayer);

    //    if (hit.collider != null)
    //    {
    //        return hit.collider.gameObject == targetTransform.gameObject;
    //    }

    //    return false;
    //}
    //private bool isPathBlocked(Vector3 targetPos)
    //{
    //    Vector2 direction = (targetPos - transform.position).normalized;
    //    float distance = Vector2.Distance(targetPos, transform.position);

    //    RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, distance, wallsLayer);

    //    return hit.collider != null;
    //}

    //void Update()
    //{
    //    if (IsStunned())
    //    {
    //        IdleHandler();
    //        return;
    //    }

    //    CheckDistanceToTarget();
    //    switch (stage)
    //    {
    //        case Stages.Idle:
    //            IdleHandler();
    //            break;
    //        case Stages.Move:
    //            MoveHandler();
    //            break;
    //        case Stages.Attack:
    //            AttackHandler();
    //            break;
    //        case Stages.Searching:
    //            SearchingHandler();
    //            break;
    //    }
    //}


    //private void CheckDistanceToTarget()
    //{
    //    if (target != null)
    //    {
    //        if (Vector2.Distance(transform.position, target.transform.position) <= attackRadius)
    //        {
    //            stage = Stages.Attack;
    //        }
    //        else if (Vector2.Distance(transform.position, target.transform.position) <= followRadius)
    //        {
    //            stage = Stages.Move;
    //        }
    //        else if (Vector2.Distance(transform.position, target.transform.position) > followRadius)
    //        {
    //            lastSeeTargetPos = target.position;
    //            target = null;
    //            stage = Stages.Searching;
    //        }
    //    }
    //}
    //private void SearchingHandler()
    //{

    //    if (!isSearching)
    //        StartCoroutine(SearchingRoutine());

    //}
    //private IEnumerator SearchingRoutine()
    //{
    //    isSearching = true;

    //    RotateSprite(lastSeeTargetPos);
    //    animator.SetBool(SEE_ENEMY_BOOL, true);
    //    agent.SetDestination(lastSeeTargetPos);

    //    while (Vector3.Distance(transform.position, lastSeeTargetPos) > 0.2f)
    //    {
    //        if (target != null)
    //        {
    //            isSearching = false;
    //            yield break;
    //        }

    //        if (isPathBlocked(lastSeeTargetPos))
    //        {
    //            agent.isStopped = true;
    //            break;
    //        }

    //        yield return null;
    //    }
    //    animator.SetBool(SEE_ENEMY_BOOL, false);

    //    yield return new WaitForSeconds(waitTimeBeforeGoingHome);

    //    RotateSprite(homePos);
    //    animator.SetBool(SEE_ENEMY_BOOL, true);
    //    agent.SetDestination(homePos);
    //    agent.isStopped = false;

    //    while (Vector3.Distance(transform.position, homePos) > 0.2f)
    //    {
    //        if (target != null)
    //        {
    //            isSearching = false;
    //            yield break;
    //        }
    //        yield return null;
    //    }

    //    animator.SetBool(SEE_ENEMY_BOOL, false);

    //    stage = Stages.Idle;

    //    isSearching = false;
    //}

    //private void IdleHandler()
    //{
    //    animator.SetBool(SEE_ENEMY_BOOL, false);
    //    rb.velocity = Vector3.zero;
    //}

    //private void MoveHandler()
    //{
    //    if (target == null)
    //        return;

    //    RotateSprite(target.position);

    //    //Vector2 moveVector = target.position - transform.position;
    //    //rb.velocity = moveVector.normalized * moveSpeed;
    //    if (DoesSeeTarget(target))
    //    {
    //        animator.SetBool(SEE_ENEMY_BOOL, true);
    //        agent.SetDestination(target.position);
    //        lastSeeTargetPos = target.position;
    //    }
    //    else
    //    {
    //        target = null;
    //        stage = Stages.Searching;
    //    }
    //}
    //private void AttackHandler()
    //{
    //    if (target == null)
    //        return;

    //    agent.SetDestination(transform.position);
    //    animator.SetBool(SEE_ENEMY_BOOL, false);
    //    RotateSprite(target.position);
    //    if (!canAttack)
    //    {
    //        return;
    //    }
    //    animator.SetTrigger(ATTACK_TRIGGER);
    //    StartCoroutine(ExecuteDelayBetweenAttacks());
    //}
    public void JumpToTarget()
    {
        RotateSprite(target.position);

        Vector2 moveVector = target.position - transform.position;
        rb.velocity = moveVector.normalized * jumpForce;
    }
    public void CauseDamage()
    {
        rb.velocity = Vector3.zero;
        Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, slimeRadius, attackLayer);
        foreach (var collider in colliders)
        {
            if (collider.gameObject == this.gameObject)
                continue;

            if (collider.TryGetComponent<IDamageable>(out var damageable))
            {
                damageable.TakeDamage(damage);
            }
        }
    }
    //private IEnumerator ExecuteDelayBetweenAttacks()
    //{
    //    canAttack = false;

    //    yield return new WaitForSeconds(delayBetweenAttacks);

    //    canAttack = true;
    //}
    //private void RotateSprite(Vector3 rotateTarget)
    //{

    //    Vector2 moveVector = rotateTarget - transform.position;

    //    if (moveVector.x < 0)
    //        transform.localScale = new Vector2(-1, transform.localScale.y);
    //    else
    //        transform.localScale = new Vector2(1, transform.localScale.y);
    //}

    //public void TakeDamage(Damage damage)
    //{
    //    currentHealth -= damage.damageAmount;
    //    UpdateHealtBar();
    //    DeathHandler();
    //}

    //private void DeathHandler()
    //{
    //    if (currentHealth <= 0)
    //    {
    //        //GiveExperience();
    //        gameObject.SetActive(false);
    //        //Destroy(gameObject);
    //    }
    //}

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, followRadius);
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, detectionRadius);
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, attackRadius);
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(transform.position, slimeRadius);
    }

    //private void UpdateHealtBar()
    //{
    //    if (currentHealth == maxHealth)
    //    {
    //        healthSlider.gameObject.SetActive(false);
    //    }
    //    else
    //    {
    //        healthSlider.gameObject.SetActive(true);
    //        healthSlider.maxValue = maxHealth;
    //        healthSlider.value = currentHealth;
    //    }
    //}
}
