using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlimeSpawner : MonoBehaviour
{
    [SerializeField] private Enemy[] enemies;
    [SerializeField] private Transform spawnPosition;

    public void SpawnSlime()
    {
        int random = Random.Range(0, enemies.Length);
        Instantiate(enemies[random], spawnPosition.position, Quaternion.identity);
    }
    public void DestroyObject()
    {
        Destroy(gameObject);
    }
}
