using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using Unity.VisualScripting;
using UnityEngine;

public class DialogueManager : MonoBehaviour
{
    public static DialogueManager Instance;

    [SerializeField] private DialogueUI dialogueUI;
    [SerializeField] private Sprite playerFace;

    private DialogueSO dialogueSO;

    private int currentLineIndex;
    private bool talking = false;

    private void Awake()
    {
        if(Instance == null)
        {
            Instance = this;
        }
    }

    public void StartDialogue(DialogueSO dialogueSOToSet)
    {
        dialogueSO = dialogueSOToSet;
        currentLineIndex = 0;
        InputUI.Instance.Hide();
        dialogueUI.Show();
        talking = true;

        TypeLine();
    }
    public void NextLine(int nextLineIndex)
    {
        if(nextLineIndex == -1)
        {
            dialogueUI.Hide();
            InputUI.Instance.Show();
           
            talking = false;
            return;
        }
        else if (nextLineIndex == 0)
        {
            currentLineIndex++;
        }
        else
        {
            currentLineIndex = nextLineIndex;
        }
        TypeLine();
    }

    private void TypeLine()
    {
        switch (dialogueSO.lines[currentLineIndex].whosTalking)
        {
            case DialogueLine.WhosTalking.Player:
                dialogueUI.TypeDialogueLine(playerFace, "�������", dialogueSO.lines[currentLineIndex]);
                //dialogueUI.TypeSentance(dialogueSO.lines[currentLineIndex].textLine, playerFace, "�������");
                break;
            case DialogueLine.WhosTalking.NPC:
                dialogueUI.TypeDialogueLine(dialogueSO.npcFace, dialogueSO.npcName, dialogueSO.lines[currentLineIndex]);
                //dialogueUI.TypeSentance(dialogueSO.lines[currentLineIndex].textLine, dialogueSO.npcFace, dialogueSO.npcName);
                break;
        }
    }
    private void Update()
    {
        if (!talking)
            return;

        if (Input.GetMouseButtonDown(0))
        {
            if (dialogueUI.IsLineTyped())
            {
                if (!dialogueSO.lines[currentLineIndex].hasOptions)
                {
                    NextLine(dialogueSO.lines[currentLineIndex].nextLine);
                }
            }
            else
            {
                dialogueUI.ShowFullText();
            }
        }
    }
}
