using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "NewPriceListSO", menuName = "ScriptableObjects/ProceListSO")]
public class PriceListSO : ScriptableObject
{
    public Sprite sellerImage;

    public ShopItem[] itemsToSell;
    public ShopItem[] itemsToBuy;
}

[System.Serializable]
public class ShopItem
{
    public InventoryItem inventoryItem;
    public int price;
}