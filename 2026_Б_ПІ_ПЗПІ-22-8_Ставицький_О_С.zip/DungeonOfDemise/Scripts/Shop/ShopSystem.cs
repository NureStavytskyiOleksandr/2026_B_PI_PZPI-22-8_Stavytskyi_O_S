using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShopSystem : MonoBehaviour
{
    public static ShopSystem Instance;

    [SerializeField] private ShopMenuUI shopMenuPrefab;
    [SerializeField] private Canvas UICanvas;

    public int SelectedSellItemID { get; private set; }

    public ShopItem SelectedBuyItem { get; private set; }

    public event EventHandler OnSellItemSelected;
    public event EventHandler OnBuyItemSelected;


    private PriceListSO currentPriceListSO;


    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
    }
    public void StartShop(PriceListSO priceList)
    {
        currentPriceListSO = priceList;

        Instantiate(shopMenuPrefab, UICanvas.transform).Initialize();
    }
    public int GetSellItemPrice(InventoryItem inventoryItem)
    {
        if (currentPriceListSO != null)
        {
            foreach (ShopItem shopItem in currentPriceListSO.itemsToSell)
            {
                if (shopItem.inventoryItem == inventoryItem)
                    return shopItem.price;
            }
            return 0;
        }
        return 0;
    }
    public void SelectItemToSell(int slotIndex)
    {
        SelectedSellItemID = slotIndex;
        OnSellItemSelected?.Invoke(this, EventArgs.Empty);
    }
    public void SellItem(float amount)
    {
        InventorySystem.Instance.SubstractItemsFromSlot(SelectedSellItemID, Convert.ToInt32(amount));
    }
    public bool CanSellItem(InventoryItem inventoryItem)
    {
        if (currentPriceListSO != null)
        {
            foreach (ShopItem shopItem in currentPriceListSO.itemsToSell)
            {
                if (shopItem.inventoryItem == inventoryItem)
                    return true;
            }
            return false;
        }
        return false;
    }
    public Sprite GetSellerImage()
    {
        return currentPriceListSO.sellerImage;
    }




    public ShopItem[] GetBuyItems()
    {
        return currentPriceListSO.itemsToBuy;
    }
    public void SetBuyItem(ShopItem shopItemToSet)
    {
        SelectedBuyItem = shopItemToSet;
        OnBuyItemSelected?.Invoke(this, EventArgs.Empty);
    }
    public void BuyItem(int amount)
    {
        if(InventorySystem.Instance.HasEnoughSlots(SelectedBuyItem.inventoryItem, amount))
        {
            for(int i = 0; i < amount; i++)
            {
                InventorySystem.Instance.SetItem(SelectedBuyItem.inventoryItem);
            }
        }
    }



    public enum ShopState
    {
        Buy,
        Sell
    }
}
