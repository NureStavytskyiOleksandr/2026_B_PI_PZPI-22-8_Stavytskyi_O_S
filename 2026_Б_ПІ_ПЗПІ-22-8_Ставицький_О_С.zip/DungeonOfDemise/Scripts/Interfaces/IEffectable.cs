using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IEffectable
{
    public void ApplyEffect(Effect effectToAdd);
    public void ApplyEffect(Effect[] effectsToAdd);
    public void ApplyHostileEffect(Effect effectToAdd);
    public void ApplyHostileEffect(Effect[] effectsToAdd);
}