using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class SwordCage : Skill
{
    [SerializeField] private Animator anim;
    [SerializeField] private float stunTime;
    [SerializeField] private Vector2 skillCenter;
    [SerializeField] private Vector2 skillSize;
    [SerializeField] private LayerMask enemyLayer;

    private const string DISAPPEAR_TRIGGER = "Dissapear";
    public void Initialize(Vector2 startPos, SwordCageLevel swordCageLevel, float magicPower)
    {
        stunTime = swordCageLevel.stunTime * magicPower;

        transform.position = startPos;
    }

    public void Stun()
    {
        Collider2D[] enemies = Physics2D.OverlapCapsuleAll((Vector2)transform.position + skillCenter, skillSize, CapsuleDirection2D.Horizontal, 0f, enemyLayer);

        List<Enemy> stunnedMonsters = new List<Enemy>();

        foreach (var enemy in enemies)
        {
            if (enemy.TryGetComponent<Enemy>(out var monster))
            {
                stunnedMonsters.Add(monster);
                monster.ActivateStun(stunTime);
            }
        }

        StartCoroutine(DisableStunAfterDelay());
    }

    private IEnumerator DisableStunAfterDelay()
    {
        yield return new WaitForSeconds(stunTime);

        //foreach (var monster in monsters)
        //{
        //    if (monster != null)
        //    {
        //        monster.DisableStun();
        //    }
        //}
        anim.SetTrigger(DISAPPEAR_TRIGGER);
    }

    public void DestroySkill()
    {
        Destroy(gameObject);
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;

        Vector2 center = (Vector2)transform.position + skillCenter;
        float width = skillSize.x;
        float height = skillSize.y;

        float radius = height / 2f;
        Vector2 rectCenter = center;
        Vector2 rectSize = new Vector2(width - height, height);

        Gizmos.DrawWireCube(rectCenter, rectSize);

        Gizmos.DrawWireSphere(center + Vector2.left * (width / 2f - radius), radius);

        Gizmos.DrawWireSphere(center + Vector2.right * (width / 2f - radius), radius);
    }
}
