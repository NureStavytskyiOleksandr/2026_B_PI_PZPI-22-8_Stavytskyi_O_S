using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public abstract class Skill : MonoBehaviour
{
    public void Initialize(Vector2 targetPos)
    {

    }

}