using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageInZoneSkillAnimationEvents : MonoBehaviour
{
    [SerializeField] private DamageInZoneSkill damageInZoneSkill;

    public void GiveDamage()
    {
        damageInZoneSkill.GiveDamage();
    }
    public void DestroySkill()
    {
        damageInZoneSkill.DestroySkill();
    }
}
