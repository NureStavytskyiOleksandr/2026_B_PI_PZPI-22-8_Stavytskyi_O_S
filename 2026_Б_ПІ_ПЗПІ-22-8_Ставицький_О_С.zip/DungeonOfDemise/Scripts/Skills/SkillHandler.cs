using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class SkillHandler
{
    public int skillID;
    public int skillLevel = 0;
    public bool isInCooldown = false;
    public SkillSO skillSO;
}